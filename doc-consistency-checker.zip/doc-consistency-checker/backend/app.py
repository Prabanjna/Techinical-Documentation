"""
Flask Application Factory for Technical Documentation Consistency Checker.
Registers Blueprints, Web UI routes, Jinja template rendering, and database initialization.
"""

import os
from flask import Flask, render_template, redirect, url_for, session, send_file

from database.db import init_db
from backend.routes.auth_routes import auth_bp
from backend.routes.analysis_routes import analysis_bp
from backend.routes.viewer_routes import viewer_bp
from backend.routes.report_routes import report_bp

def create_app(config=None):
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    template_dir = os.path.join(base_dir, "frontend", "templates")
    static_dir = os.path.join(base_dir, "frontend", "static")

    app = Flask(
        __name__,
        template_folder=template_dir,
        static_folder=static_dir
    )

    app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "doc-consistency-secret-key-2026")
    app.config["MAX_CONTENT_LENGTH"] = 64 * 1024 * 1024  # 64 MB max upload

    # Initialize Database Tables
    init_db()

    # Register API Blueprints
    app.register_blueprint(auth_bp)
    app.register_blueprint(analysis_bp)
    app.register_blueprint(viewer_bp)
    app.register_blueprint(report_bp)

    # Web Page UI Routes
    @app.route("/")
    def index():
        if "user_id" in session:
            return redirect(url_for("dashboard"))
        return redirect(url_for("login"))

    @app.route("/login")
    def login():
        return render_template("login.html")

    @app.route("/dashboard")
    def dashboard():
        return render_template("dashboard.html")

    @app.route("/upload")
    def upload():
        return render_template("upload.html")

    @app.route("/analyzing")
    def analyzing():
        return render_template("analyzing.html")

    @app.route("/results/<int:analysis_id>")
    def results(analysis_id):
        return render_template("results.html", analysis_id=analysis_id)

    @app.route("/visual-diff/<int:analysis_id>")
    def visual_diff(analysis_id):
        return render_template("visual_diff.html", analysis_id=analysis_id)

    @app.route("/download-zip")
    def download_zip():
        candidates = [
            os.path.join(os.path.dirname(base_dir), "doc-consistency-checker.zip"),
            os.path.join(base_dir, "doc-consistency-checker.zip")
        ]
        for p in candidates:
            if os.path.exists(p):
                return send_file(p, as_attachment=True, download_name="doc-consistency-checker.zip")
        return "Project ZIP archive not found on disk.", 404

    return app

if __name__ == "__main__":
    app = create_app()
    app.run(host="127.0.0.1", port=5000, debug=True)
