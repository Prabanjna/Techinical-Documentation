"""
PDF Report Generator Service using ReportLab.
Produces an executive technical documentation consistency report with:
- Executive Summary & Overall Consistency Gauge
- Issue Breakdown by Severity (Critical, Moderate, Minor)
- Side-by-Side Contradictory Section Tables with Highlighted Diff Keywords
- Full Audit Trail and Neural Confidence Metrics
"""

import io
from datetime import datetime
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable, KeepTogether
)

class PDFReportGenerator:
    @classmethod
    def generate(cls, analysis_data: dict) -> bytes:
        """
        Generates a PDF report from analysis results dictionary and returns bytes.
        """
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(
            buffer,
            pagesize=letter,
            rightMargin=36,
            leftMargin=36,
            topMargin=36,
            bottomMargin=36
        )

        styles = getSampleStyleSheet()
        
        # Custom typography
        title_style = ParagraphStyle(
            'DocTitle',
            parent=styles['Heading1'],
            fontName='Helvetica-Bold',
            fontSize=20,
            leading=24,
            textColor=colors.HexColor('#0f172a'),
            spaceAfter=4
        )
        subtitle_style = ParagraphStyle(
            'DocSubtitle',
            parent=styles['Normal'],
            fontName='Helvetica',
            fontSize=10,
            leading=14,
            textColor=colors.HexColor('#64748b'),
            spaceAfter=12
        )
        heading2_style = ParagraphStyle(
            'SectionH2',
            parent=styles['Heading2'],
            fontName='Helvetica-Bold',
            fontSize=13,
            leading=16,
            textColor=colors.HexColor('#1e293b'),
            spaceBefore=14,
            spaceAfter=8
        )
        body_style = ParagraphStyle(
            'BodyNormal',
            parent=styles['Normal'],
            fontName='Helvetica',
            fontSize=9,
            leading=12,
            textColor=colors.HexColor('#334155')
        )
        cell_bold = ParagraphStyle(
            'CellBold',
            parent=styles['Normal'],
            fontName='Helvetica-Bold',
            fontSize=9,
            leading=12,
            textColor=colors.HexColor('#0f172a')
        )
        code_style = ParagraphStyle(
            'SnippetText',
            parent=styles['Normal'],
            fontName='Courier',
            fontSize=8,
            leading=11,
            textColor=colors.HexColor('#1e293b')
        )

        story = []

        # 1. Document Header
        story.append(Paragraph("Technical Documentation Consistency Audit Report", title_style))
        story.append(Paragraph(
            f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M UTC')} | "
            f"Comparison: <b>{analysis_data.get('doc_a_name', 'Doc A')}</b> vs <b>{analysis_data.get('doc_b_name', 'Doc B')}</b>",
            subtitle_style
        ))
        story.append(HRFlowable(width="100%", thickness=1.5, color=colors.HexColor('#2563eb'), spaceAfter=14))

        # 2. Executive Summary Metrics Table
        overall_score = analysis_data.get("overall_score", 100.0)
        total_pairs = analysis_data.get("total_pairs", 0)
        contra_count = analysis_data.get("contradiction_count", 0)
        consistent_count = analysis_data.get("consistent_count", 0)
        crit_count = analysis_data.get("critical_count", 0)
        mod_count = analysis_data.get("moderate_count", 0)
        min_count = analysis_data.get("minor_count", 0)

        summary_data = [
            [
                Paragraph("<b>Overall Consistency</b>", cell_bold),
                Paragraph("<b>Total Sections Checked</b>", cell_bold),
                Paragraph("<b>Contradictions Flagged</b>", cell_bold),
                Paragraph("<b>Critical Issues</b>", cell_bold),
                Paragraph("<b>Moderate Issues</b>", cell_bold)
            ],
            [
                Paragraph(f"<font size='14' color='#16a34a'><b>{overall_score:.1f}%</b></font>", body_style),
                Paragraph(f"<font size='14'><b>{total_pairs}</b></font>", body_style),
                Paragraph(f"<font size='14' color='#dc2626'><b>{contra_count}</b></font>", body_style),
                Paragraph(f"<font size='14' color='#dc2626'><b>{crit_count}</b></font>", body_style),
                Paragraph(f"<font size='14' color='#d97706'><b>{mod_count}</b></font>", body_style),
            ]
        ]
        summary_table = Table(summary_data, colWidths=[110, 110, 110, 105, 105])
        summary_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#f8fafc')),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('INNERGRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#e2e8f0')),
            ('BOX', (0, 0), (-1, -1), 1, colors.HexColor('#cbd5e1')),
            ('TOPPADDING', (0, 0), (-1, -1), 6),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
        ]))
        story.append(summary_table)
        story.append(Spacer(1, 14))

        # 3. Contradictions Section
        story.append(Paragraph("Flagged Inconsistencies & Contradictions", heading2_style))
        inconsistencies = analysis_data.get("inconsistencies", [])
        contra_items = [item for item in inconsistencies if item.get("is_contradictory")]

        if not contra_items:
            story.append(Paragraph("No contradictory requirements or parameter drifts were identified. All evaluated sections are semantically synchronized.", body_style))
        else:
            for idx, item in enumerate(contra_items, 1):
                sev = item.get("severity", "Moderate")
                conf = item.get("confidence", 0.0)
                sim = item.get("similarity_score", 0.0)

                # Severity header badge color
                if sev == "Critical":
                    badge_color = "#dc2626"
                    card_bg = "#fef2f2"
                elif sev == "Moderate":
                    badge_color = "#d97706"
                    card_bg = "#fffbeb"
                else:
                    badge_color = "#2563eb"
                    card_bg = "#eff6ff"

                sec_a_title = item.get("section_a_title", "Section A")
                sec_b_title = item.get("section_b_title", "Section B")
                text_a = item.get("section_a_text", "").replace("\n", " ")
                text_b = item.get("section_b_text", "").replace("\n", " ")
                exp = item.get("explanation", "Neural classifier identified conflicting requirements.")
                influential_a = ", ".join(item.get("influential_words_a", [])[:5]) or "None"
                influential_b = ", ".join(item.get("influential_words_b", [])[:5]) or "None"

                header_text = (
                    f"<b>#{idx} • {sev.upper()} SEVERITY</b> | "
                    f"Confidence: <b>{conf:.1f}%</b> | Semantic Match: <b>{sim:.1f}%</b>"
                )

                item_table_data = [
                    [
                        Paragraph(f"<font color='{badge_color}'>{header_text}</font>", cell_bold),
                        ""
                    ],
                    [
                        Paragraph(f"<b>Baseline ({analysis_data.get('doc_a_name', 'Doc A')}):</b> {sec_a_title}", cell_bold),
                        Paragraph(f"<b>Updated ({analysis_data.get('doc_b_name', 'Doc B')}):</b> {sec_b_title}", cell_bold)
                    ],
                    [
                        Paragraph(text_a, code_style),
                        Paragraph(text_b, code_style)
                    ],
                    [
                        Paragraph(f"<b>Key Conflict Terms:</b> {influential_a}", body_style),
                        Paragraph(f"<b>Key Conflict Terms:</b> {influential_b}", body_style)
                    ],
                    [
                        Paragraph(f"<b>Analysis Rationale:</b> {exp}", body_style),
                        ""
                    ]
                ]

                item_table = Table(item_table_data, colWidths=[270, 270])
                item_table.setStyle(TableStyle([
                    ('SPAN', (0, 0), (1, 0)),
                    ('SPAN', (0, 4), (1, 4)),
                    ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor(card_bg)),
                    ('BACKGROUND', (0, 1), (-1, -1), colors.white),
                    ('BOX', (0, 0), (-1, -1), 1, colors.HexColor('#cbd5e1')),
                    ('INNERGRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#f1f5f9')),
                    ('TOPPADDING', (0, 0), (-1, -1), 5),
                    ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
                    ('LEFTPADDING', (0, 0), (-1, -1), 8),
                    ('RIGHTPADDING', (0, 0), (-1, -1), 8),
                ]))

                story.append(KeepTogether([item_table, Spacer(1, 10)]))

        # Build PDF
        doc.build(story)
        pdf_bytes = buffer.getvalue()
        buffer.close()
        return pdf_bytes
