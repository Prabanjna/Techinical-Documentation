"""
Document Extraction and Semantic Chunking Service.
Supports PDF (PyMuPDF) and DOCX (python-docx).
Cleans boilerplate, normalizes whitespace, extracts text blocks,
and retains exact bounding box coordinates and paragraph offsets for visual diffing.
"""

import os
import re
import pymupdf as fitz
import docx

class DocumentExtractor:
    @classmethod
    def extract(cls, file_path: str) -> list[dict]:
        """
        Detects file extension and extracts structured chunks.
        Returns list of chunk dicts:
        [
            {
                "id": "chunk_1",
                "title": "Section Title / Paragraph",
                "text": "Cleaned chunk text content...",
                "page": 1,
                "bbox": [x0, y0, x1, y1] (for PDF),
                "para_idx": 0 (for DOCX)
            },
            ...
        ]
        """
        ext = os.path.splitext(file_path)[1].lower()
        if ext == ".pdf":
            return cls.extract_pdf(file_path)
        elif ext in (".docx", ".doc"):
            return cls.extract_docx(file_path)
        elif ext in (".txt", ".md"):
            return cls.extract_txt(file_path)
        else:
            raise ValueError(f"Unsupported file format: {ext}. Only PDF and DOCX are supported.")

    @classmethod
    def extract_pdf(cls, file_path: str) -> list[dict]:
        doc = fitz.open(file_path)
        chunks = []
        chunk_counter = 1

        for page_num in range(len(doc)):
            page = doc[page_num]
            # text blocks: (x0, y0, x1, y1, "text", block_no, block_type)
            blocks = page.get_text("blocks")

            current_title = f"Page {page_num + 1} Section"
            for b in blocks:
                if len(b) < 5:
                    continue
                raw_text = b[4]
                cleaned = cls._clean_text(raw_text)
                
                # Skip empty or negligible boilerplate
                if len(cleaned.split()) < 4 or cls._is_boilerplate(cleaned):
                    continue

                bbox = [round(b[0], 1), round(b[1], 1), round(b[2], 1), round(b[3], 1)]

                # Check if block looks like a header
                first_line = cleaned.split("\n")[0].strip()
                if len(first_line) < 60 and (first_line.isupper() or ":" in first_line or not first_line.endswith(".")):
                    current_title = first_line
                    body_text = "\n".join(cleaned.split("\n")[1:]).strip()
                    if not body_text:
                        body_text = cleaned
                else:
                    body_text = cleaned

                chunks.append({
                    "id": f"chunk_{chunk_counter}",
                    "title": current_title[:80],
                    "text": body_text,
                    "page": page_num + 1,
                    "bbox": bbox,
                    "para_idx": None
                })
                chunk_counter += 1

        doc.close()
        return chunks

    @classmethod
    def extract_docx(cls, file_path: str) -> list[dict]:
        doc = docx.Document(file_path)
        chunks = []
        chunk_counter = 1
        current_heading = "General Overview"

        for idx, para in enumerate(doc.paragraphs):
            raw_text = para.text
            cleaned = cls._clean_text(raw_text)

            if not cleaned or len(cleaned.split()) < 3 or cls._is_boilerplate(cleaned):
                continue

            # Check if paragraph has heading style
            style_name = para.style.name.lower() if para.style else ""
            if "heading" in style_name or "title" in style_name:
                current_heading = cleaned
                continue

            chunks.append({
                "id": f"chunk_{chunk_counter}",
                "title": current_heading[:80],
                "text": cleaned,
                "page": 1,  # DOCX is continuous flow
                "bbox": None,
                "para_idx": idx
            })
            chunk_counter += 1

        # Also inspect tables if any
        for table_idx, table in enumerate(doc.tables):
            for row_idx, row in enumerate(table.rows):
                row_cells = [cls._clean_text(cell.text) for cell in row.cells if cls._clean_text(cell.text)]
                if len(row_cells) >= 2:
                    table_text = " | ".join(row_cells)
                    chunks.append({
                        "id": f"chunk_{chunk_counter}",
                        "title": f"Table {table_idx + 1} - Row {row_idx + 1}",
                        "text": table_text,
                        "page": 1,
                        "bbox": None,
                        "para_idx": 1000 + table_idx * 100 + row_idx
                    })
                    chunk_counter += 1

        return chunks

    @classmethod
    def extract_txt(cls, file_path: str) -> list[dict]:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            lines = f.readlines()

        chunks = []
        current_title = "Overview"
        current_buffer = []
        chunk_counter = 1

        for line in lines:
            cleaned = line.strip()
            if not cleaned:
                if current_buffer:
                    full_text = " ".join(current_buffer)
                    if len(full_text.split()) >= 4:
                        chunks.append({
                            "id": f"chunk_{chunk_counter}",
                            "title": current_title,
                            "text": full_text,
                            "page": 1,
                            "bbox": None,
                            "para_idx": None
                        })
                        chunk_counter += 1
                    current_buffer = []
                continue

            if cleaned.startswith("#") or cleaned.isupper() or cleaned.endswith(":"):
                current_title = cleaned.lstrip("#").strip()
            else:
                current_buffer.append(cleaned)

        if current_buffer:
            full_text = " ".join(current_buffer)
            chunks.append({
                "id": f"chunk_{chunk_counter}",
                "title": current_title,
                "text": full_text,
                "page": 1,
                "bbox": None,
                "para_idx": None
            })

        return chunks

    @staticmethod
    def _clean_text(text: str) -> str:
        """Removes extraneous carriage returns and normalizes whitespace."""
        if not text:
            return ""
        # Remove non-printable characters except standard whitespace
        text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', text)
        # Collapse excessive whitespace
        text = re.sub(r'[ \t]+', ' ', text)
        text = re.sub(r'\n\s*\n+', '\n', text)
        return text.strip()

    @staticmethod
    def _is_boilerplate(text: str) -> bool:
        """Flags headers, footers, page numbers, and copyright notices."""
        low = text.lower()
        if re.match(r'^\s*page\s+\d+(\s+of\s+\d+)?\s*$', low):
            return True
        if "confidential" in low and len(text) < 40:
            return True
        if "all rights reserved" in low:
            return True
        if re.match(r'^\s*©\s*\d{4}', low):
            return True
        return False
