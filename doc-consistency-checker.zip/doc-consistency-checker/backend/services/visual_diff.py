"""
Visual Diff Document Rendering Service.
- For PDF: Renders document pages as high-resolution images via PyMuPDF with
  semi-transparent highlighted overlay bounding-boxes over contradictory sections.
- For DOCX: Converts document structure into formatted HTML with highlighted
  inconsistent paragraphs and anchor IDs for synchronized side-by-side navigation.
"""

import io
import os
import pymupdf as fitz
import docx

class VisualDiffRenderer:
    @classmethod
    def render_pdf_page_image(
        cls,
        pdf_path: str,
        page_num: int = 1,
        highlight_boxes: list[dict] = None,
        dpi: int = 144
    ) -> bytes:
        """
        Renders a specific page of a PDF with color-coded highlight boxes directly on the canvas.
        highlight_boxes: list of dicts with:
            {
                "bbox": [x0, y0, x1, y1],
                "severity": "Critical" | "Moderate" | "Minor",
                "label": "Section 1"
            }
        Returns: PNG image bytes.
        """
        doc = fitz.open(pdf_path)
        if page_num < 1 or page_num > len(doc):
            page_num = 1

        page = doc[page_num - 1]

        # Draw highlight rectangles on the page if provided
        if highlight_boxes:
            for item in highlight_boxes:
                bbox = item.get("bbox")
                if not bbox or len(bbox) != 4:
                    continue
                severity = item.get("severity", "Moderate")
                
                # Color mapping: RGB in [0, 1]
                if severity == "Critical":
                    stroke_color = (0.85, 0.15, 0.15)  # Crimson red
                    fill_color = (1.0, 0.85, 0.85)
                elif severity == "Moderate":
                    stroke_color = (0.95, 0.55, 0.10)  # Amber
                    fill_color = (1.0, 0.93, 0.80)
                else:
                    stroke_color = (0.20, 0.55, 0.90)  # Blue
                    fill_color = (0.88, 0.94, 1.0)

                rect = fitz.Rect(bbox[0] - 2, bbox[1] - 2, bbox[2] + 2, bbox[3] + 2)
                # Draw filled transparent rectangle
                page.draw_rect(rect, color=stroke_color, fill=fill_color, fill_opacity=0.35, width=1.5)

        pix = page.get_pixmap(dpi=dpi)
        img_bytes = pix.tobytes("png")
        doc.close()
        return img_bytes

    @classmethod
    def get_pdf_page_count(cls, pdf_path: str) -> int:
        """Returns total page count of a PDF."""
        doc = fitz.open(pdf_path)
        count = len(doc)
        doc.close()
        return count

    @classmethod
    def render_docx_html(
        cls,
        docx_path: str,
        highlight_paras: dict[int, dict] = None
    ) -> str:
        """
        Converts DOCX into a structured, readable HTML document with
        inconsistent sections highlighted.
        highlight_paras: dict mapping paragraph index -> {
            "severity": "Critical",
            "section_id": "chunk_3",
            "title": "Payload Limits"
        }
        """
        if highlight_paras is None:
            highlight_paras = {}

        doc = docx.Document(docx_path)
        html_parts = [
            '<div class="docx-rendered-doc">',
            f'<div class="docx-doc-header">Original Layout Preview: {os.path.basename(docx_path)}</div>'
        ]

        for idx, para in enumerate(doc.paragraphs):
            text = para.text.strip()
            if not text:
                continue

            style_name = para.style.name.lower() if para.style else ""
            is_highlighted = (idx in highlight_paras)

            wrapper_class = ""
            badge_html = ""
            section_attr = ""

            if is_highlighted:
                info = highlight_paras[idx]
                sev = info.get("severity", "Moderate").lower()
                sec_id = info.get("section_id", f"p_{idx}")
                wrapper_class = f"docx-para-highlight highlight-{sev}"
                section_attr = f'id="docx-section-{sec_id}" data-severity="{sev}"'
                badge_html = f'<div class="docx-badge badge-{sev}">[Contradiction Flag: {sev.capitalize()}]</div>'

            if "heading 1" in style_name or "title" in style_name:
                html_parts.append(f'<h2 class="docx-h1 {wrapper_class}" {section_attr}>{badge_html}{text}</h2>')
            elif "heading 2" in style_name:
                html_parts.append(f'<h3 class="docx-h2 {wrapper_class}" {section_attr}>{badge_html}{text}</h3>')
            elif "heading 3" in style_name:
                html_parts.append(f'<h4 class="docx-h3 {wrapper_class}" {section_attr}>{badge_html}{text}</h4>')
            else:
                html_parts.append(f'<p class="docx-p {wrapper_class}" {section_attr}>{badge_html}{text}</p>')

        # Render tables
        for table_idx, table in enumerate(doc.tables):
            html_parts.append('<table class="docx-table">')
            for row_idx, row in enumerate(table.rows):
                html_parts.append('<tr>')
                for cell in row.cells:
                    cell_text = cell.text.strip()
                    tag = "th" if row_idx == 0 else "td"
                    html_parts.append(f'<{tag}>{cell_text}</{tag}>')
                html_parts.append('</tr>')
            html_parts.append('</table>')

        html_parts.append('</div>')
        return "\n".join(html_parts)
