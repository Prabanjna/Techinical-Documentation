"""
Visual Diff Viewer Routes.
Serves rendered PDF page images with highlighted bounding boxes
and styled DOCX HTML representations for original context diff inspection.
"""

import json
from flask import Blueprint, jsonify, send_file, Response, abort
from database.db import SessionLocal
from database.models import Analysis, Inconsistency
from backend.services.visual_diff import VisualDiffRenderer

viewer_bp = Blueprint("viewer", __name__, url_prefix="/api/viewer")

@viewer_bp.route("/<int:analysis_id>/meta", methods=["GET"])
def get_viewer_meta(analysis_id):
    """Returns document metadata and list of inconsistency coordinates for the viewer."""
    db = SessionLocal()
    try:
        analysis = db.query(Analysis).filter(Analysis.id == analysis_id).first()
        if not analysis:
            return jsonify({"error": "Analysis not found"}), 404

        inconsistencies = db.query(Inconsistency).filter(
            Inconsistency.analysis_id == analysis_id
        ).all()

        total_pages_a = 1
        total_pages_b = 1

        if analysis.doc_a_format == "pdf" and analysis.doc_a_path:
            try:
                total_pages_a = VisualDiffRenderer.get_pdf_page_count(analysis.doc_a_path)
            except Exception:
                total_pages_a = 1

        if analysis.doc_b_format == "pdf" and analysis.doc_b_path:
            try:
                total_pages_b = VisualDiffRenderer.get_pdf_page_count(analysis.doc_b_path)
            except Exception:
                total_pages_b = 1

        items = []
        for inc in inconsistencies:
            items.append({
                "id": inc.id,
                "is_contradictory": inc.is_contradictory,
                "severity": inc.severity,
                "confidence": inc.confidence,
                "section_a_title": inc.section_a_title,
                "page_a": inc.page_a,
                "bbox_a": json.loads(inc.bbox_a) if inc.bbox_a else None,
                "para_idx_a": inc.para_idx_a,

                "section_b_title": inc.section_b_title,
                "page_b": inc.page_b,
                "bbox_b": json.loads(inc.bbox_b) if inc.bbox_b else None,
                "para_idx_b": inc.para_idx_b,
                "explanation": inc.explanation
            })

        return jsonify({
            "analysis_id": analysis.id,
            "title": analysis.title,
            "doc_a": {
                "name": analysis.doc_a_name,
                "format": analysis.doc_a_format,
                "total_pages": total_pages_a
            },
            "doc_b": {
                "name": analysis.doc_b_name,
                "format": analysis.doc_b_format,
                "total_pages": total_pages_b
            },
            "items": items
        }), 200
    finally:
        db.close()

@viewer_bp.route("/<int:analysis_id>/doc/<doc_role>/page/<int:page_num>", methods=["GET"])
def get_pdf_page_image(analysis_id, doc_role, page_num):
    """Renders a PDF page with bounding-box highlights as PNG."""
    role = doc_role.lower()
    if role not in ("a", "b"):
        abort(400, "Invalid doc role. Must be 'a' or 'b'.")

    db = SessionLocal()
    try:
        analysis = db.query(Analysis).filter(Analysis.id == analysis_id).first()
        if not analysis:
            abort(404, "Analysis not found")

        file_path = analysis.doc_a_path if role == "a" else analysis.doc_b_path
        doc_format = analysis.doc_a_format if role == "a" else analysis.doc_b_format

        if doc_format != "pdf" or not file_path:
            abort(400, "Requested document is not a PDF")

        # Collect bounding boxes for this page
        inconsistencies = db.query(Inconsistency).filter(
            Inconsistency.analysis_id == analysis_id,
            Inconsistency.is_contradictory == True
        ).all()

        highlight_boxes = []
        for inc in inconsistencies:
            p_num = inc.page_a if role == "a" else inc.page_b
            raw_bbox = inc.bbox_a if role == "a" else inc.bbox_b
            if p_num == page_num and raw_bbox:
                bbox = json.loads(raw_bbox)
                highlight_boxes.append({
                    "bbox": bbox,
                    "severity": inc.severity,
                    "label": inc.section_a_title if role == "a" else inc.section_b_title
                })

        img_bytes = VisualDiffRenderer.render_pdf_page_image(
            pdf_path=file_path,
            page_num=page_num,
            highlight_boxes=highlight_boxes,
            dpi=144
        )

        return Response(img_bytes, mimetype="image/png")
    finally:
        db.close()

@viewer_bp.route("/<int:analysis_id>/doc/<doc_role>/html", methods=["GET"])
def get_docx_rendered_html(analysis_id, doc_role):
    """Renders a DOCX file as styled HTML with highlighted inconsistent sections."""
    role = doc_role.lower()
    if role not in ("a", "b"):
        abort(400, "Invalid doc role. Must be 'a' or 'b'.")

    db = SessionLocal()
    try:
        analysis = db.query(Analysis).filter(Analysis.id == analysis_id).first()
        if not analysis:
            abort(404, "Analysis not found")

        file_path = analysis.doc_a_path if role == "a" else analysis.doc_b_path
        doc_format = analysis.doc_a_format if role == "a" else analysis.doc_b_format

        if doc_format not in ("docx", "doc") or not file_path:
            abort(400, "Requested document is not a DOCX")

        inconsistencies = db.query(Inconsistency).filter(
            Inconsistency.analysis_id == analysis_id,
            Inconsistency.is_contradictory == True
        ).all()

        highlight_paras = {}
        for inc in inconsistencies:
            para_idx = inc.para_idx_a if role == "a" else inc.para_idx_b
            if para_idx is not None:
                highlight_paras[para_idx] = {
                    "severity": inc.severity,
                    "section_id": inc.id,
                    "title": inc.section_a_title if role == "a" else inc.section_b_title
                }

        rendered_html = VisualDiffRenderer.render_docx_html(
            docx_path=file_path,
            highlight_paras=highlight_paras
        )

        return jsonify({"html": rendered_html}), 200
    finally:
        db.close()
