"""
Report Export Routes.
Generates and downloads the executive audit PDF report for an analysis.
"""

import json
from flask import Blueprint, Response, abort
from database.db import SessionLocal
from database.models import Analysis, Inconsistency
from backend.services.pdf_report import PDFReportGenerator

report_bp = Blueprint("reports", __name__, url_prefix="/api/reports")

@report_bp.route("/<int:analysis_id>/export-pdf", methods=["GET"])
def export_pdf(analysis_id):
    db = SessionLocal()
    try:
        analysis = db.query(Analysis).filter(Analysis.id == analysis_id).first()
        if not analysis:
            abort(404, "Analysis not found")

        inconsistencies = db.query(Inconsistency).filter(
            Inconsistency.analysis_id == analysis_id
        ).all()

        incons_list = []
        for inc in inconsistencies:
            incons_list.append({
                "id": inc.id,
                "section_a_title": inc.section_a_title,
                "section_a_text": inc.section_a_text,
                "section_b_title": inc.section_b_title,
                "section_b_text": inc.section_b_text,
                "similarity_score": inc.similarity_score,
                "confidence": inc.confidence,
                "is_contradictory": inc.is_contradictory,
                "severity": inc.severity,
                "explanation": inc.explanation,
                "influential_words_a": json.loads(inc.influential_words_a) if inc.influential_words_a else [],
                "influential_words_b": json.loads(inc.influential_words_b) if inc.influential_words_b else []
            })

        analysis_dict = {
            "title": analysis.title,
            "doc_a_name": analysis.doc_a_name,
            "doc_b_name": analysis.doc_b_name,
            "overall_score": analysis.overall_score,
            "total_pairs": analysis.total_pairs,
            "contradiction_count": analysis.contradiction_count,
            "consistent_count": analysis.consistent_count,
            "critical_count": analysis.critical_count,
            "moderate_count": analysis.moderate_count,
            "minor_count": analysis.minor_count,
            "created_at": analysis.created_at.strftime("%Y-%m-%d %H:%M"),
            "inconsistencies": incons_list
        }

        pdf_bytes = PDFReportGenerator.generate(analysis_dict)
        filename = f"Consistency_Report_{analysis.id}_{analysis.doc_a_name.split('.')[0]}_vs_{analysis.doc_b_name.split('.')[0]}.pdf"

        return Response(
            pdf_bytes,
            mimetype="application/pdf",
            headers={
                "Content-Disposition": f'attachment; filename="{filename}"'
            }
        )
    finally:
        db.close()
