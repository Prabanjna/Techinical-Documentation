"""
Authentication Routes for Technical Documentation Consistency Checker.
Supports user registration, login, session validation, and 1-click Demo Reviewer login.
Uses Werkzeug secure password hashing.
"""

from flask import Blueprint, request, jsonify, session
from werkzeug.security import generate_password_hash, check_password_hash
from database.db import SessionLocal
from database.models import User

auth_bp = Blueprint("auth", __name__, url_prefix="/auth")

@auth_bp.route("/register", methods=["POST"])
def register():
    data = request.get_json() or {}
    username = data.get("username", "").strip()
    password = data.get("password", "").strip()

    if not username or not password:
        return jsonify({"error": "Username and password are required"}), 400

    if len(password) < 4:
        return jsonify({"error": "Password must be at least 4 characters long"}), 400

    db = SessionLocal()
    try:
        existing = db.query(User).filter(User.username == username).first()
        if existing:
            return jsonify({"error": f"Username '{username}' already exists. Please pick another."}), 400

        user = User(
            username=username,
            password_hash=generate_password_hash(password),
            role="engineer"
        )
        db.add(user)
        db.commit()
        db.refresh(user)

        session["user_id"] = user.id
        session["username"] = user.username
        session["role"] = user.role

        return jsonify({
            "message": "Registration successful",
            "user": {"id": user.id, "username": user.username, "role": user.role}
        }), 201
    finally:
        db.close()

@auth_bp.route("/login", methods=["POST"])
def login():
    data = request.get_json() or {}
    username = data.get("username", "").strip()
    password = data.get("password", "").strip()

    if not username or not password:
        return jsonify({"error": "Username and password are required"}), 400

    db = SessionLocal()
    try:
        user = db.query(User).filter(User.username == username).first()
        if not user or not check_password_hash(user.password_hash, password):
            return jsonify({"error": "Invalid username or password"}), 401

        session["user_id"] = user.id
        session["username"] = user.username
        session["role"] = user.role

        return jsonify({
            "message": "Login successful",
            "user": {"id": user.id, "username": user.username, "role": user.role}
        }), 200
    finally:
        db.close()

@auth_bp.route("/demo-login", methods=["POST"])
def demo_login():
    """Instant 1-click login for examiners and project evaluators."""
    db = SessionLocal()
    try:
        demo_user = db.query(User).filter(User.username == "reviewer_demo").first()
        if not demo_user:
            demo_user = User(
                username="reviewer_demo",
                password_hash=generate_password_hash("reviewer2026"),
                role="Project Examiner"
            )
            db.add(demo_user)
            db.commit()
            db.refresh(demo_user)

        session["user_id"] = demo_user.id
        session["username"] = demo_user.username
        session["role"] = demo_user.role

        return jsonify({
            "message": "Logged in as Project Examiner",
            "user": {"id": demo_user.id, "username": demo_user.username, "role": demo_user.role}
        }), 200
    finally:
        db.close()

@auth_bp.route("/logout", methods=["POST", "GET"])
def logout():
    session.clear()
    return jsonify({"message": "Logged out successfully"}), 200

@auth_bp.route("/me", methods=["GET"])
def current_user():
    user_id = session.get("user_id")
    if not user_id:
        return jsonify({"authenticated": False}), 200

    db = SessionLocal()
    try:
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            session.clear()
            return jsonify({"authenticated": False}), 200
        return jsonify({
            "authenticated": True,
            "user": {"id": user.id, "username": user.username, "role": user.role}
        }), 200
    finally:
        db.close()
