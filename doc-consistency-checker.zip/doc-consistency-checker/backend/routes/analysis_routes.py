"""
Analysis Routes for Technical Documentation Consistency Checker.
Handles document uploads, pipeline execution, results querying, and preset demo scenarios.
"""

import os
import json
from datetime import datetime
from flask import Blueprint, request, jsonify, session, current_app
from werkzeug.utils import secure_filename

from database.db import SessionLocal
from database.models import Analysis, Inconsistency, User
from backend.services.extractor import DocumentExtractor
from ml.pipeline import ConsistencyPipeline

analysis_bp = Blueprint("analysis", __name__, url_prefix="/api")

# Lazy pipeline singleton
_pipeline_instance = None

def get_pipeline():
    global _pipeline_instance
    if _pipeline_instance is None:
        _pipeline_instance = ConsistencyPipeline()
    return _pipeline_instance

UPLOAD_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

SAMPLE_DOCS_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "data", "sample_docs"
)

DEMO_PRESETS = [
    {
        "id": "db-arch-pdf",
        "title": "Database Architecture Spec (v1.0 vs v2.0)",
        "description": "PostgreSQL replication topology, min replica count (3 vs 5 nodes), TLS port (5432 vs 5433), and WAL archiving limits.",
        "doc_a": "Database_Architecture_v1.pdf",
        "doc_b": "Database_Architecture_v2.pdf",
        "format": "pdf"
    },
    {
        "id": "cloud-sdk-docx",
        "title": "Cloud SDK & Auth Guide (v1.4 vs v2.0)",
        "description": "OAuth2 endpoint changes, HMAC SHA-256 vs Ed25519 signatures, payload limits (10MB vs 50MB), and deprecations.",
        "doc_a": "CloudSDK_Spec_v1.docx",
        "doc_b": "CloudSDK_Spec_v2.docx",
        "format": "docx"
    }
]

@analysis_bp.route("/demo-presets", methods=["GET"])
def list_presets():
    return jsonify({"presets": DEMO_PRESETS}), 200

@analysis_bp.route("/analyses", methods=["GET"])
def list_analyses():
    user_id = session.get("user_id")
    db = SessionLocal()
    try:
        query = db.query(Analysis)
        if user_id:
            query = query.filter(Analysis.user_id == user_id)
        analyses = query.order_by(Analysis.created_at.desc()).all()

        results = []
        for a in analyses:
            results.append({
                "id": a.id,
                "title": a.title,
                "doc_a_name": a.doc_a_name,
                "doc_b_name": a.doc_b_name,
                "doc_a_format": a.doc_a_format,
                "doc_b_format": a.doc_b_format,
                "overall_score": a.overall_score,
                "total_pairs": a.total_pairs,
                "contradiction_count": a.contradiction_count,
                "consistent_count": a.consistent_count,
                "critical_count": a.critical_count,
                "moderate_count": a.moderate_count,
                "minor_count": a.minor_count,
                "status": a.status,
                "created_at": a.created_at.strftime("%Y-%m-%d %H:%M")
            })
        return jsonify({"analyses": results}), 200
    finally:
        db.close()

@analysis_bp.route("/analyses/<int:analysis_id>", methods=["GET"])
def get_analysis_detail(analysis_id):
    db = SessionLocal()
    try:
        analysis = db.query(Analysis).filter(Analysis.id == analysis_id).first()
        if not analysis:
            return jsonify({"error": "Analysis not found"}), 404

        inconsistencies = db.query(Inconsistency).filter(
            Inconsistency.analysis_id == analysis_id
        ).all()

        incons_data = []
        for inc in inconsistencies:
            incons_data.append({
                "id": inc.id,
                "section_a_id": inc.section_a_id,
                "section_a_title": inc.section_a_title,
                "section_a_text": inc.section_a_text,
                "page_a": inc.page_a,
                "bbox_a": json.loads(inc.bbox_a) if inc.bbox_a else None,
                "para_idx_a": inc.para_idx_a,

                "section_b_id": inc.section_b_id,
                "section_b_title": inc.section_b_title,
                "section_b_text": inc.section_b_text,
                "page_b": inc.page_b,
                "bbox_b": json.loads(inc.bbox_b) if inc.bbox_b else None,
                "para_idx_b": inc.para_idx_b,

                "similarity_score": inc.similarity_score,
                "confidence": inc.confidence,
                "is_contradictory": inc.is_contradictory,
                "prediction_label": inc.prediction_label,
                "severity": inc.severity,
                "explanation": inc.explanation,
                "influential_words_a": json.loads(inc.influential_words_a) if inc.influential_words_a else [],
                "influential_words_b": json.loads(inc.influential_words_b) if inc.influential_words_b else [],
                "highlighted_text_a": inc.highlighted_text_a,
                "highlighted_text_b": inc.highlighted_text_b
            })

        return jsonify({
            "id": analysis.id,
            "title": analysis.title,
            "doc_a_name": analysis.doc_a_name,
            "doc_b_name": analysis.doc_b_name,
            "doc_a_format": analysis.doc_a_format,
            "doc_b_format": analysis.doc_b_format,
            "overall_score": analysis.overall_score,
            "total_pairs": analysis.total_pairs,
            "contradiction_count": analysis.contradiction_count,
            "consistent_count": analysis.consistent_count,
            "critical_count": analysis.critical_count,
            "moderate_count": analysis.moderate_count,
            "minor_count": analysis.minor_count,
            "status": analysis.status,
            "created_at": analysis.created_at.strftime("%Y-%m-%d %H:%M"),
            "inconsistencies": incons_data
        }), 200
    finally:
        db.close()

@analysis_bp.route("/analyses/<int:analysis_id>", methods=["DELETE"])
def delete_analysis(analysis_id):
    db = SessionLocal()
    try:
        analysis = db.query(Analysis).filter(Analysis.id == analysis_id).first()
        if not analysis:
            return jsonify({"error": "Analysis not found"}), 404
        db.delete(analysis)
        db.commit()
        return jsonify({"message": "Analysis deleted successfully"}), 200
    finally:
        db.close()

@analysis_bp.route("/run-preset", methods=["POST"])
def run_preset():
    data = request.get_json() or {}
    preset_id = data.get("preset_id")

    preset = next((p for p in DEMO_PRESETS if p["id"] == preset_id), None)
    if not preset:
        return jsonify({"error": "Unknown preset ID"}), 400

    path_a = os.path.join(SAMPLE_DOCS_DIR, preset["doc_a"])
    path_b = os.path.join(SAMPLE_DOCS_DIR, preset["doc_b"])

    if not (os.path.exists(path_a) and os.path.exists(path_b)):
        return jsonify({"error": "Sample documents not found on disk"}), 404

    return _execute_comparison(
        title=preset["title"],
        path_a=path_a,
        path_b=path_b,
        name_a=preset["doc_a"],
        name_b=preset["doc_b"]
    )

@analysis_bp.route("/upload-and-analyze", methods=["POST"])
def upload_and_analyze():
    if "file_a" not in request.files or "file_b" not in request.files:
        return jsonify({"error": "Both file_a and file_b are required"}), 400

    file_a = request.files["file_a"]
    file_b = request.files["file_b"]

    if file_a.filename == "" or file_b.filename == "":
        return jsonify({"error": "Please select both files"}), 400

    title = request.form.get("title", "").strip()
    if not title:
        title = f"Comparison: {file_a.filename} vs {file_b.filename}"

    filename_a = secure_filename(file_a.filename)
    filename_b = secure_filename(file_b.filename)

    timestamp = int(datetime.utcnow().timestamp())
    save_path_a = os.path.join(UPLOAD_DIR, f"{timestamp}_a_{filename_a}")
    save_path_b = os.path.join(UPLOAD_DIR, f"{timestamp}_b_{filename_b}")

    file_a.save(save_path_a)
    file_b.save(save_path_b)

    return _execute_comparison(
        title=title,
        path_a=save_path_a,
        path_b=save_path_b,
        name_a=filename_a,
        name_b=filename_b
    )

def _execute_comparison(title: str, path_a: str, path_b: str, name_a: str, name_b: str):
    """Executes the complete end-to-end extraction and ML pipeline."""
    pipeline = get_pipeline()

    ext_a = os.path.splitext(path_a)[1].lstrip(".").lower()
    ext_b = os.path.splitext(path_b)[1].lstrip(".").lower()

    # 1. Extraction & Chunking
    chunks_a = DocumentExtractor.extract(path_a)
    chunks_b = DocumentExtractor.extract(path_b)

    if not chunks_a or not chunks_b:
        return jsonify({"error": "Could not extract sufficient text chunks from one or both documents."}), 400

    # 2. Neural Pipeline Execution
    analysis_result = pipeline.analyze_documents(chunks_a, chunks_b)

    # 3. Store in Database
    db = SessionLocal()
    try:
        user_id = session.get("user_id")
        analysis_record = Analysis(
            user_id=user_id,
            title=title,
            doc_a_name=name_a,
            doc_b_name=name_b,
            doc_a_path=path_a,
            doc_b_path=path_b,
            doc_a_format=ext_a,
            doc_b_format=ext_b,
            overall_score=analysis_result["overall_consistency_score"],
            total_pairs=analysis_result["total_comparisons"],
            contradiction_count=analysis_result["contradictions_count"],
            consistent_count=analysis_result["consistent_count"],
            critical_count=analysis_result["critical_count"],
            moderate_count=analysis_result["moderate_count"],
            minor_count=analysis_result["minor_count"],
            status="completed"
        )
        db.add(analysis_record)
        db.commit()
        db.refresh(analysis_record)

        # Add Inconsistencies
        for comp in analysis_result["comparisons"]:
            inc = Inconsistency(
                analysis_id=analysis_record.id,
                section_a_id=comp.get("section_a_id"),
                section_a_title=comp.get("section_a_title", "Section A"),
                section_a_text=comp.get("section_a_text", ""),
                page_a=comp.get("page_a", 1),
                bbox_a=json.dumps(comp.get("bbox_a")) if comp.get("bbox_a") else None,
                para_idx_a=comp.get("para_idx_a"),

                section_b_id=comp.get("section_b_id"),
                section_b_title=comp.get("section_b_title", "Section B"),
                section_b_text=comp.get("section_b_text", ""),
                page_b=comp.get("page_b", 1),
                bbox_b=json.dumps(comp.get("bbox_b")) if comp.get("bbox_b") else None,
                para_idx_b=comp.get("para_idx_b"),

                similarity_score=comp.get("similarity_score", 0.0),
                confidence=comp.get("confidence", 0.0),
                is_contradictory=comp.get("is_contradictory", False),
                prediction_label=comp.get("prediction_label", "Consistent"),
                severity=comp.get("severity", "None"),
                explanation=comp.get("explanation", ""),
                influential_words_a=json.dumps(comp.get("influential_words_a", [])),
                influential_words_b=json.dumps(comp.get("influential_words_b", [])),
                highlighted_text_a=comp.get("highlighted_text_a", ""),
                highlighted_text_b=comp.get("highlighted_text_b", "")
            )
            db.add(inc)

        db.commit()

        return jsonify({
            "message": "Analysis completed successfully",
            "analysis_id": analysis_record.id,
            "overall_score": analysis_record.overall_score,
            "contradiction_count": analysis_record.contradiction_count
        }), 201
    finally:
        db.close()
