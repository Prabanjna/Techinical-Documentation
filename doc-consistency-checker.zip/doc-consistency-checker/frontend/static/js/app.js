/**
 * DocConsistency AI - Frontend Application Logic
 * Vanilla JavaScript (No heavy external frameworks)
 */

const App = {
    currentUser: null,
    currentResults: null,
    activeFilter: 'all',

    // ==========================================
    // Auth Management
    // ==========================================
    async init() {
        try {
            const res = await fetch("/auth/me");
            const data = await res.json();
            if (data.authenticated) {
                this.currentUser = data.user;
                this.updateNavUser(data.user);
            } else {
                const path = window.location.pathname;
                if (path !== "/login" && path !== "/") {
                    // Allowed public preview or redirect
                }
            }
        } catch (err) {
            console.error("Auth check failed:", err);
        }
    },

    updateNavUser(user) {
        const navUserBadge = document.getElementById("navUserBadge");
        const navUsername = document.getElementById("navUsername");
        if (navUserBadge && navUsername) {
            navUserBadge.textContent = user.role || "Engineer";
            navUsername.textContent = user.username;
        }
    },

    async loginDemo() {
        try {
            const res = await fetch("/auth/demo-login", { method: "POST" });
            const data = await res.json();
            if (res.ok) {
                window.location.href = "/dashboard";
            } else {
                alert(data.error || "Demo login failed");
            }
        } catch (err) {
            alert("Connection error during demo login");
        }
    },

    async handleLogin(e) {
        e.preventDefault();
        const username = document.getElementById("loginUsername").value.trim();
        const password = document.getElementById("loginPassword").value.trim();
        const errBox = document.getElementById("loginError");
        errBox.style.display = "none";

        try {
            const res = await fetch("/auth/login", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ username, password })
            });
            const data = await res.json();
            if (res.ok) {
                window.location.href = "/dashboard";
            } else {
                errBox.textContent = data.error || "Invalid username or password";
                errBox.style.display = "block";
            }
        } catch (err) {
            errBox.textContent = "Server unreachable. Please ensure backend is running.";
            errBox.style.display = "block";
        }
    },

    async handleRegister(e) {
        e.preventDefault();
        const username = document.getElementById("regUsername").value.trim();
        const password = document.getElementById("regPassword").value.trim();
        const errBox = document.getElementById("regError");
        const succBox = document.getElementById("regSuccess");
        errBox.style.display = "none";
        succBox.style.display = "none";

        try {
            const res = await fetch("/auth/register", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ username, password })
            });
            const data = await res.json();
            if (res.ok) {
                succBox.textContent = "Account created! Signing in...";
                succBox.style.display = "block";
                setTimeout(() => { window.location.href = "/dashboard"; }, 600);
            } else {
                errBox.textContent = data.error || "Registration failed";
                errBox.style.display = "block";
            }
        } catch (err) {
            errBox.textContent = "Server unreachable.";
            errBox.style.display = "block";
        }
    },

    async logout() {
        await fetch("/auth/logout", { method: "POST" });
        window.location.href = "/login";
    },

    // ==========================================
    // Dashboard Logic
    // ==========================================
    async loadDashboardData() {
        try {
            const res = await fetch("/api/analyses");
            const data = await res.json();
            const analyses = data.analyses || [];

            // Stats calculation
            const total = analyses.length;
            let totalContras = 0;
            let totalCrits = 0;
            let sumScores = 0;

            analyses.forEach(a => {
                totalContras += (a.contradiction_count || 0);
                totalCrits += (a.critical_count || 0);
                sumScores += (a.overall_score || 0);
            });

            const avgScore = total > 0 ? (sumScores / total).toFixed(1) : "--";

            document.getElementById("statTotalAudits").textContent = total;
            document.getElementById("statAvgScore").textContent = avgScore !== "--" ? `${avgScore}%` : "--%";
            document.getElementById("statTotalContradictions").textContent = totalContras;
            document.getElementById("statCriticalIssues").textContent = totalCrits;

            // Render Table
            const tbody = document.getElementById("analysesTableBody");
            if (analyses.length === 0) {
                tbody.innerHTML = `
                    <tr>
                        <td colspan="6" class="text-center py-5">
                            <div style="font-size: 1.1rem; color: #64748b; margin-bottom: 0.5rem;">No document consistency audits yet.</div>
                            <p style="font-size: 0.85rem; color: #94a3b8; margin-bottom: 1rem;">Upload two technical documents or try a pre-configured scenario above.</p>
                            <a href="/upload" class="btn btn-primary btn-sm">+ Start First Comparison</a>
                        </td>
                    </tr>
                `;
                return;
            }

            tbody.innerHTML = analyses.map(a => {
                const scoreColor = a.overall_score >= 85 ? "text-success" : (a.overall_score >= 65 ? "text-warning" : "text-danger");
                const hasContra = a.contradiction_count > 0;
                
                return `
                    <tr>
                        <td>
                            <strong>${this.escapeHtml(a.title)}</strong>
                        </td>
                        <td>
                            <div style="display: flex; align-items: center; gap: 0.4rem; font-size: 0.85rem;">
                                <span class="badge-doc-a">${this.escapeHtml(a.doc_a_name)}</span>
                                <span class="vs-divider">vs</span>
                                <span class="badge-doc-b">${this.escapeHtml(a.doc_b_name)}</span>
                            </div>
                        </td>
                        <td>
                            <span class="pill pill-success ${scoreColor}" style="font-size: 0.85rem; font-weight: 700;">
                                ${a.overall_score.toFixed(1)}%
                            </span>
                        </td>
                        <td>
                            ${hasContra ? 
                                `<span class="badge-severity critical">${a.contradiction_count} Flagged (${a.critical_count} Critical)</span>` : 
                                `<span class="badge-severity consistent">0 (Clean)</span>`}
                        </td>
                        <td style="font-size: 0.8rem; color: #64748b;">${a.created_at}</td>
                        <td>
                            <div class="table-actions">
                                <a href="/results/${a.id}" class="btn btn-sm btn-outline">Results</a>
                                <a href="/visual-diff/${a.id}" class="btn btn-sm btn-outline">Visual Diff</a>
                                <a href="/api/reports/${a.id}/export-pdf" class="btn btn-sm btn-outline" title="Download PDF">PDF</a>
                                <button class="btn btn-sm btn-clear" onclick="App.deleteAnalysis(${a.id})" title="Delete">✕</button>
                            </div>
                        </td>
                    </tr>
                `;
            }).join("");

        } catch (err) {
            console.error("Dashboard loading error:", err);
        }
    },

    async deleteAnalysis(id) {
        if (!confirm("Are you sure you want to delete this analysis report?")) return;
        try {
            await fetch(`/api/analyses/${id}`, { method: "DELETE" });
            this.loadDashboardData();
        } catch (err) {
            alert("Failed to delete analysis");
        }
    },

    async runPreset(presetId) {
        window.location.href = `/analyzing?preset=${presetId}`;
    },

    // ==========================================
    // Upload Management
    // ==========================================
    handleFileSelect(docRole, input) {
        if (!input.files || !input.files[0]) return;
        const file = input.files[0];
        const infoDiv = document.getElementById(`fileInfo${docRole}`);
        const nameSpan = document.getElementById(`fileName${docRole}`);
        const sizeSpan = document.getElementById(`fileSize${docRole}`);

        nameSpan.textContent = file.name;
        sizeSpan.textContent = `(${(file.size / 1024).toFixed(1)} KB)`;
        infoDiv.style.display = "flex";
    },

    clearFile(docRole) {
        const input = document.getElementById(`file${docRole}`);
        input.value = "";
        document.getElementById(`fileInfo${docRole}`).style.display = "none";
    },

    handleUpload(e) {
        e.preventDefault();
        const fileA = document.getElementById("fileA").files[0];
        const fileB = document.getElementById("fileB").files[0];
        const errBox = document.getElementById("uploadError");
        errBox.style.display = "none";

        if (!fileA || !fileB) {
            errBox.textContent = "Please select both Document A and Document B to compare.";
            errBox.style.display = "block";
            return;
        }

        // Store in sessionStorage or navigate to analyzing
        const title = document.getElementById("comparisonTitle").value.trim();
        const formData = new FormData();
        formData.append("file_a", fileA);
        formData.append("file_b", fileB);
        if (title) formData.append("title", title);

        const btn = document.getElementById("btnSubmitUpload");
        btn.disabled = true;
        btn.textContent = "Uploading & Running Pipeline...";

        fetch("/api/upload-and-analyze", {
            method: "POST",
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            if (data.analysis_id) {
                window.location.href = `/results/${data.analysis_id}`;
            } else {
                errBox.textContent = data.error || "Analysis failed";
                errBox.style.display = "block";
                btn.disabled = false;
                btn.textContent = "⚡ Run Local Consistency Check";
            }
        })
        .catch(err => {
            errBox.textContent = "Network error during analysis upload.";
            errBox.style.display = "block";
            btn.disabled = false;
            btn.textContent = "⚡ Run Local Consistency Check";
        });
    },

    // ==========================================
    // Analyzing Screen Simulator / Runner
    // ==========================================
    async startAnalysisSimulation() {
        const urlParams = new URLSearchParams(window.location.search);
        const presetId = urlParams.get("preset");

        const steps = [
            { id: "step1", name: "Stage 1 of 6: Text Extraction", text: "Extracting text blocks & coordinates via PyMuPDF / python-docx...", pct: "18%" },
            { id: "step2", name: "Stage 2 of 6: Semantic Chunking", text: "Normalizing text and segmenting into logical context sections...", pct: "36%" },
            { id: "step3", name: "Stage 3 of 6: Siamese BiLSTM Embeddings", text: "Generating 128-d dense vector embeddings using local PyTorch weights...", pct: "55%" },
            { id: "step4", name: "Stage 4 of 6: Cosine Candidate Alignment", text: "Computing cross-document similarity matrix to align corresponding topics...", pct: "72%" },
            { id: "step5", name: "Stage 5 of 6: Neural Classification", text: "Classifying aligned pairs as Consistent vs Contradictory...", pct: "88%" },
            { id: "step6", name: "Stage 6 of 6: Explainability & Severity", text: "Extracting token attention weights, inline highlights, and severity ratings...", pct: "98%" }
        ];

        let currentStep = 0;
        const interval = setInterval(() => {
            if (currentStep < steps.length) {
                const s = steps[currentStep];
                document.getElementById("progressFill").style.width = s.pct;
                document.getElementById("progressPct").textContent = s.pct;
                document.getElementById("progressStepName").textContent = s.name;
                document.getElementById("analyzingStatusText").textContent = s.text;

                if (currentStep > 0) {
                    const prevEl = document.getElementById(steps[currentStep - 1].id);
                    prevEl.classList.remove("active");
                    prevEl.classList.add("completed");
                    prevEl.querySelector(".step-icon").textContent = "✓";
                }
                const curEl = document.getElementById(s.id);
                curEl.classList.add("active");
                curEl.querySelector(".step-icon").textContent = "🔄";
                currentStep++;
            } else {
                clearInterval(interval);
            }
        }, 600);

        if (presetId) {
            try {
                const res = await fetch("/api/run-preset", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ preset_id: presetId })
                });
                const data = await res.json();
                if (data.analysis_id) {
                    setTimeout(() => {
                        window.location.href = `/results/${data.analysis_id}`;
                    }, 3800);
                } else {
                    alert(data.error || "Preset execution failed");
                    window.location.href = "/upload";
                }
            } catch (err) {
                alert("Error running preset");
                window.location.href = "/upload";
            }
        }
    },

    // ==========================================
    // Results Dashboard
    // ==========================================
    async loadAnalysisResults(analysisId) {
        try {
            const res = await fetch(`/api/analyses/${analysisId}`);
            const data = await res.json();
            if (!res.ok) {
                document.getElementById("inconsistenciesList").innerHTML = `<div class="alert alert-danger">Error: ${data.error}</div>`;
                return;
            }

            this.currentResults = data;

            // Update Header & Links
            document.getElementById("analysisTitle").textContent = data.title;
            document.getElementById("metaDocA").textContent = `Doc A: ${data.doc_a_name}`;
            document.getElementById("metaDocB").textContent = `Doc B: ${data.doc_b_name}`;
            document.getElementById("metaDate").textContent = `Audited on ${data.created_at}`;

            document.getElementById("btnVisualDiff").href = `/visual-diff/${data.id}`;
            document.getElementById("btnExportPdf").href = `/api/reports/${data.id}/export-pdf`;

            // Update Score Metrics
            const score = data.overall_score || 0;
            const scoreValEl = document.getElementById("overallScoreVal");
            const scoreFillEl = document.getElementById("overallScoreFill");
            scoreValEl.textContent = `${score.toFixed(1)}%`;
            scoreFillEl.style.width = `${score}%`;

            if (score >= 85) {
                scoreValEl.className = "score-number text-success";
                scoreFillEl.style.background = "var(--success)";
                document.getElementById("scoreDescription").textContent = "High Synchronization: Documentation versions are largely consistent.";
            } else if (score >= 65) {
                scoreValEl.className = "score-number text-warning";
                scoreFillEl.style.background = "var(--warning)";
                document.getElementById("scoreDescription").textContent = "Moderate Divergence: Several parameters or procedures conflict.";
            } else {
                scoreValEl.className = "score-number text-danger";
                scoreFillEl.style.background = "var(--danger)";
                document.getElementById("scoreDescription").textContent = "Severe Contradictions: High frequency of conflicting specifications detected.";
            }

            document.getElementById("statContradictionsCount").textContent = data.contradiction_count;
            document.getElementById("statConsistentCount").textContent = data.consistent_count;

            document.getElementById("statCritCount").textContent = data.critical_count;
            document.getElementById("statModCount").textContent = data.moderate_count;
            document.getElementById("statMinCount").textContent = data.minor_count;

            // Filter Counts
            document.getElementById("filterCountAll").textContent = data.total_pairs;
            document.getElementById("filterCountCrit").textContent = data.critical_count;
            document.getElementById("filterCountMod").textContent = data.moderate_count;
            document.getElementById("filterCountMin").textContent = data.minor_count;
            document.getElementById("filterCountConsistent").textContent = data.consistent_count;

            this.renderComparisonCards(data.inconsistencies);

        } catch (err) {
            console.error("Results load error:", err);
        }
    },

    filterResults(type, btnElement) {
        this.activeFilter = type;
        document.querySelectorAll(".filter-pill").forEach(p => p.classList.remove("active"));
        if (btnElement) btnElement.classList.add("active");

        if (!this.currentResults) return;

        let filtered = this.currentResults.inconsistencies;
        if (type === 'critical') {
            filtered = filtered.filter(i => i.is_contradictory && i.severity === "Critical");
        } else if (type === 'moderate') {
            filtered = filtered.filter(i => i.is_contradictory && i.severity === "Moderate");
        } else if (type === 'minor') {
            filtered = filtered.filter(i => i.is_contradictory && i.severity === "Minor");
        } else if (type === 'consistent') {
            filtered = filtered.filter(i => !i.is_contradictory);
        }

        this.renderComparisonCards(filtered);
    },

    renderComparisonCards(items) {
        const container = document.getElementById("inconsistenciesList");
        if (!items || items.length === 0) {
            container.innerHTML = `
                <div class="card text-center py-5" style="background: white; border-radius: var(--radius-md); border: 1px solid var(--slate-200);">
                    <p style="color: #64748b; font-weight: 500;">No section comparisons match the selected filter criteria.</p>
                </div>
            `;
            return;
        }

        container.innerHTML = items.map((item, idx) => {
            const isContra = item.is_contradictory;
            const sev = item.severity || "None";
            const sevClass = isContra ? `sev-${sev.toLowerCase()}` : "sev-consistent";
            const sevLabel = isContra ? `${sev} Severity` : "Fully Consistent";

            // Influential keywords badges
            const wordsA = item.influential_words_a || [];
            const wordsB = item.influential_words_b || [];

            const textA = item.highlighted_text_a || this.escapeHtml(item.section_a_text);
            const textB = item.highlighted_text_b || this.escapeHtml(item.section_b_text);

            return `
                <div class="inconsistency-card">
                    <div class="card-top-bar">
                        <div class="card-top-left">
                            <span class="card-index">#${idx + 1}</span>
                            <span class="badge-severity ${sevClass}">${sevLabel}</span>
                            <strong style="font-size: 0.95rem; color: #0f172a;">
                                ${this.escapeHtml(item.section_a_title)} ↔ ${this.escapeHtml(item.section_b_title)}
                            </strong>
                        </div>
                        <div class="card-top-right">
                            <span class="card-metric">Model Confidence: <strong>${item.confidence.toFixed(1)}%</strong></span>
                            <span class="card-metric">Cosine Alignment: <strong>${item.similarity_score.toFixed(1)}%</strong></span>
                        </div>
                    </div>

                    <div class="comparison-side-by-side">
                        <!-- Baseline Section -->
                        <div class="comp-column comp-column-a">
                            <div class="comp-col-header">
                                <h4>Baseline (${this.escapeHtml(this.currentResults.doc_a_name)})</h4>
                                <span class="loc-tag">Page ${item.page_a || 1}</span>
                            </div>
                            <div class="comp-text-body">${textA}</div>
                            ${wordsA.length > 0 ? `
                                <div class="conflict-tags-row">
                                    <span class="conflict-tags-label">Influential Keywords:</span>
                                    ${wordsA.map(w => `<span class="conflict-tag">${this.escapeHtml(w)}</span>`).join("")}
                                </div>
                            ` : ''}
                        </div>

                        <!-- Updated Section -->
                        <div class="comp-column comp-column-b">
                            <div class="comp-col-header">
                                <h4>Updated (${this.escapeHtml(this.currentResults.doc_b_name)})</h4>
                                <span class="loc-tag">Page ${item.page_b || 1}</span>
                            </div>
                            <div class="comp-text-body">${textB}</div>
                            ${wordsB.length > 0 ? `
                                <div class="conflict-tags-row">
                                    <span class="conflict-tags-label">Influential Keywords:</span>
                                    ${wordsB.map(w => `<span class="conflict-tag">${this.escapeHtml(w)}</span>`).join("")}
                                </div>
                            ` : ''}
                        </div>
                    </div>

                    <div class="card-explanation-footer">
                        <span class="explanation-icon">💡</span>
                        <div>
                            <strong>Explainability Rationale:</strong>
                            <span>${this.escapeHtml(item.explanation || "No explanation recorded.")}</span>
                        </div>
                    </div>
                </div>
            `;
        }).join("");
    },

    escapeHtml(str) {
        if (!str) return "";
        return String(str)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;");
    }
};

// ==========================================
// Visual Diff Engine
// ==========================================
const VisualDiff = {
    analysisId: null,
    meta: null,
    contradictions: [],
    currentIndex: 0,
    currentPageA: 1,
    currentPageB: 1,
    zoomScale: 1.0,

    async init(analysisId) {
        this.analysisId = analysisId;
        try {
            const res = await fetch(`/api/viewer/${analysisId}/meta`);
            const meta = await res.json();
            this.meta = meta;

            document.getElementById("diffDocTitle").textContent = meta.title;
            document.getElementById("paneDocAName").textContent = meta.doc_a.name;
            document.getElementById("paneDocBName").textContent = meta.doc_b.name;

            // Filter contradictory items only for navigation
            this.contradictions = (meta.items || []).filter(i => i.is_contradictory);
            this.currentIndex = 0;

            // Setup Page Controls for PDF
            this.setupPageControls('a', meta.doc_a);
            this.setupPageControls('b', meta.doc_b);

            // Render initial views
            this.renderDocument('a', meta.doc_a, 1);
            this.renderDocument('b', meta.doc_b, 1);

            if (this.contradictions.length > 0) {
                this.jumpToIssue(0);
            } else {
                document.getElementById("issueCounter").textContent = "0 Inconsistencies";
            }
        } catch (err) {
            console.error("Visual diff init error:", err);
        }
    },

    setupPageControls(role, docMeta) {
        const controls = document.getElementById(`pageControls${role.toUpperCase()}`);
        const select = document.getElementById(`selectPage${role.toUpperCase()}`);
        const totalSpan = document.getElementById(`totalPages${role.toUpperCase()}`);

        if (docMeta.format === "pdf" && docMeta.total_pages > 1) {
            controls.style.display = "flex";
            totalSpan.textContent = `/ ${docMeta.total_pages}`;
            select.innerHTML = Array.from({ length: docMeta.total_pages }, (_, i) => i + 1)
                .map(p => `<option value="${p}">${p}</option>`).join("");
        } else {
            controls.style.display = "none";
        }
    },

    async renderDocument(role, docMeta, pageNum) {
        const wrapper = document.getElementById(`canvasWrapper${role.toUpperCase()}`);
        wrapper.innerHTML = `<div class="viewport-loading">Loading original layout...</div>`;

        if (docMeta.format === "pdf") {
            const imgUrl = `/api/viewer/${this.analysisId}/doc/${role}/page/${pageNum}?t=${Date.now()}`;
            const img = new Image();
            img.src = imgUrl;
            img.onload = () => {
                wrapper.innerHTML = "";
                wrapper.appendChild(img);
            };
            img.onerror = () => {
                wrapper.innerHTML = `<div class="alert alert-danger">Error rendering PDF page.</div>`;
            };
        } else if (docMeta.format === "docx" || docMeta.format === "doc") {
            try {
                const res = await fetch(`/api/viewer/${this.analysisId}/doc/${role}/html`);
                const data = await res.json();
                wrapper.innerHTML = data.html || "<p>No content extracted.</p>";
            } catch (err) {
                wrapper.innerHTML = `<div class="alert alert-danger">Error rendering DOCX layout.</div>`;
            }
        }
    },

    jumpToIssue(index) {
        if (!this.contradictions || this.contradictions.length === 0) return;
        if (index < 0) index = 0;
        if (index >= this.contradictions.length) index = this.contradictions.length - 1;
        this.currentIndex = index;

        const issue = this.contradictions[index];
        const total = this.contradictions.length;

        document.getElementById("issueCounter").textContent = `Issue ${index + 1} of ${total}`;

        // Banner update
        const banner = document.getElementById("activeIssueBanner");
        banner.style.display = "flex";
        const sevBadge = document.getElementById("bannerSeverityBadge");
        sevBadge.textContent = issue.severity;
        sevBadge.className = `badge-severity sev-${issue.severity.toLowerCase()}`;

        document.getElementById("bannerIssueTitle").textContent = `${issue.section_a_title} ↔ ${issue.section_b_title}`;
        document.getElementById("bannerConfidence").textContent = `${issue.confidence.toFixed(1)}% Confidence`;
        document.getElementById("bannerExplanation").textContent = issue.explanation;

        // Jump pages if PDF
        if (this.meta.doc_a.format === "pdf" && issue.page_a) {
            this.changePage('a', issue.page_a);
        }
        if (this.meta.doc_b.format === "pdf" && issue.page_b) {
            this.changePage('b', issue.page_b);
        }

        // Scroll to highlighted element if DOCX
        if (this.meta.doc_a.format !== "pdf") {
            const targetElA = document.getElementById(`docx-section-${issue.id}`);
            if (targetElA) targetElA.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
        if (this.meta.doc_b.format !== "pdf") {
            const targetElB = document.getElementById(`docx-section-${issue.id}`);
            if (targetElB) targetElB.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    },

    nextIssue() {
        if (this.currentIndex < this.contradictions.length - 1) {
            this.jumpToIssue(this.currentIndex + 1);
        }
    },

    prevIssue() {
        if (this.currentIndex > 0) {
            this.jumpToIssue(this.currentIndex - 1);
        }
    },

    changePage(role, pageNum) {
        pageNum = parseInt(pageNum);
        if (role === 'a') {
            this.currentPageA = pageNum;
            const sel = document.getElementById("selectPageA");
            if (sel) sel.value = pageNum;
            this.renderDocument('a', this.meta.doc_a, pageNum);
        } else {
            this.currentPageB = pageNum;
            const sel = document.getElementById("selectPageB");
            if (sel) sel.value = pageNum;
            this.renderDocument('b', this.meta.doc_b, pageNum);
        }
    },

    zoomIn() {
        this.zoomScale = Math.min(2.0, this.zoomScale + 0.15);
        this.applyZoom();
    },

    zoomOut() {
        this.zoomScale = Math.max(0.6, this.zoomScale - 0.15);
        this.applyZoom();
    },

    resetZoom() {
        this.zoomScale = 1.0;
        this.applyZoom();
    },

    applyZoom() {
        document.getElementById("zoomLevel").textContent = `${Math.round(this.zoomScale * 100)}%`;
        const wrapA = document.getElementById("canvasWrapperA");
        const wrapB = document.getElementById("canvasWrapperB");
        if (wrapA) wrapA.style.transform = `scale(${this.zoomScale})`;
        if (wrapB) wrapB.style.transform = `scale(${this.zoomScale})`;
    }
};

// Global startup
document.addEventListener("DOMContentLoaded", () => {
    App.init();
});
