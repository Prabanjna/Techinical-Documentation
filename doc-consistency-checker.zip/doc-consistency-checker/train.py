"""
Master Training and Evaluation Pipeline.
Trains both the custom Siamese Embedding Network and Consistency Classifier
from scratch, saves checkpoints to ml/checkpoints/, and prints evaluation metrics.
Zero external AI APIs or pretrained models.
"""

import os
import sys
import time

# Force UTF-8 stream handling if available
if sys.stdout and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

# Ensure project root is in python path
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

from ml.train_embedding import train_embedding_model
from ml.train_classifier import train_classifier_model
from ml.evaluate import evaluate_models

def run_full_training():
    start_time = time.time()
    data_path = os.path.join(ROOT_DIR, "data", "sample_training_data.json")

    print("\n" + "=" * 70)
    print("[*] STARTING FROM-SCRATCH ML TRAINING PIPELINE")
    print("    - Zero Pretrained Checkpoints")
    print("    - Zero External AI APIs")
    print("    - Framework: PyTorch (Offline Neural Networks)")
    print("=" * 70 + "\n")

    # Step 1: Train Embedding Network
    print("--- [STAGE 1/3]: Training Siamese BiLSTM Embedding Model ---")
    train_embedding_model(data_path=data_path, epochs=25, batch_size=16, lr=1e-3)

    # Step 2: Train Consistency Classifier Network
    print("\n--- [STAGE 2/3]: Training Neural Consistency Classifier ---")
    train_classifier_model(data_path=data_path, epochs=30, batch_size=16, lr=2e-3)

    # Step 3: Run Evaluation Suite
    print("\n--- [STAGE 3/3]: Running Academic Evaluation on Test Split ---")
    metrics = evaluate_models(data_path=data_path)

    elapsed = time.time() - start_time
    print("\n" + "=" * 70)
    print(f"[+] TRAINING COMPLETE in {elapsed:.1f}s!")
    print(f"    Accuracy: {metrics['accuracy']*100:.2f}% | F1-Score: {metrics['f1']*100:.2f}%")
    print("    All weights and vocab are stored locally in 'ml/checkpoints/'")
    print("=" * 70 + "\n")

if __name__ == "__main__":
    run_full_training()
