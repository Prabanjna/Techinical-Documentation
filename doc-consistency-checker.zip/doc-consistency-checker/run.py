"""
Application Entry Point for Technical Documentation Consistency Checker.
Runs the Flask application server on local port 5000.
"""

import sys
import os

# Set UTF-8 stream handling
if sys.stdout and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

from backend.app import create_app

app = create_app()

if __name__ == "__main__":
    print("\n" + "=" * 65)
    print("🚀 Technical Documentation Consistency Checker Server Starting")
    print("   • Local Address: http://127.0.0.1:5000")
    print("   • Zero External AI APIs | 100% Local Neural Networks")
    print("=" * 65 + "\n")
    app.run(host="127.0.0.1", port=5000, debug=True)
