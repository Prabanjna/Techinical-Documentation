# LLM-Based Technical Documentation Consistency Checker

> **Final-Year Engineering Project • Local & Offline Machine Learning System**  
> An automated consistency and contradiction detection web application for technical documentation, software specifications, and architecture releases.

---

## 📌 1. Project Overview & Hard Constraints Compliance

When technical documentation, cloud SDKs, or database specifications evolve across software releases, discrepancies often emerge: obsolete configuration parameters, conflicting network port bindings, shifted memory limits, and deprecated endpoints.

This project implements a **100% local, offline AI consistency checking system** built under strict operational constraints:

| Hard Constraint | Status | Implementation Details |
| :--- | :---: | :--- |
| **Zero External AI APIs** | ✅ Guaranteed | Absolutely no calls to OpenAI, Anthropic, Google Gemini, Cohere, or Hugging Face Inference APIs. No cloud dependencies. |
| **Zero Pretrained Models** | ✅ Guaranteed | No Hugging Face transformers, no spaCy, no GloVe/word2vec checkpoints. Every neural network is trained from randomly initialized weights locally on our dataset. |
| **100% Offline Inference** | ✅ Guaranteed | PyTorch models, tokenizers, and database run completely on local CPU/GPU with zero network calls required after initial library installation. |
| **Lightweight Web Stack** | ✅ Guaranteed | Python 3.x, Flask (modular Blueprints), vanilla HTML/CSS/JS (no bulky frontend frameworks), and SQLite (SQLAlchemy ORM). |

---

## 🏗️ 2. Architectural Pipeline

```
          [Document A: Baseline]           [Document B: Updated]
                     │                                │
                     ▼                                ▼
            ┌──────────────────────────────────────────────────┐
            │       Multi-Format Extraction (PDF & DOCX)       │
            │   PyMuPDF (bounding-boxes) & python-docx (paras) │
            └─────────────────────────┬────────────────────────┘
                                      │
                                      ▼
            ┌──────────────────────────────────────────────────┐
            │     Text Normalization & Semantic Chunking       │
            │   Boilerplate/header removal, paragraph context  │
            └─────────────────────────┬────────────────────────┘
                                      │
                                      ▼
            ┌──────────────────────────────────────────────────┐
            │   Siamese Dual-Encoder BiLSTM (From Scratch)     │
            │  128-d Dense Unit Hypersphere Embeddings         │
            └─────────────────────────┬────────────────────────┘
                                      │
                                      ▼
            ┌──────────────────────────────────────────────────┐
            │         Cosine Similarity Matrix Matching        │
            │     Identifies top semantically aligned pairs    │
            └─────────────────────────┬────────────────────────┘
                                      │
                                      ▼
            ┌──────────────────────────────────────────────────┐
            │       Neural Consistency Classifier Network      │
            │ Interaction: [u; v; |u-v|; u*v] -> (0: Consistent│
            │                                     1: Conflict) │
            └─────────────────────────┬────────────────────────┘
                                      │
                         ┌────────────┴────────────┐
                         ▼                         ▼
            ┌─────────────────────────┐ ┌─────────────────────────┐
            │   Explainability Layer  │ │  Severity Engine (Rule  │
            │  Per-token attention &  │ │   + Confidence Scorer)  │
            │  difflib keyword diffs  │ │Critical / Moderate/Minor│
            └────────────┬────────────┘ └────────────┬────────────┘
                         │                           │
                         └────────────┬──────────────┘
                                      │
                                      ▼
            ┌──────────────────────────────────────────────────┐
            │  Interactive Result Dashboard & Visual Diff View │
            │ Side-by-side cards, original PDF/DOCX overlays,  │
            │   and downloadable Executive Audit PDF Reports   │
            └──────────────────────────────────────────────────┘
```

---

## 🧠 3. Machine Learning Technical Details

### A. Siamese BiLSTM Embedding Network (`ml/models.py`)
- **Architecture**:
  - Embedding Layer ($V \times 128$)
  - 2-Layer Bidirectional LSTM ($128$ hidden units, dropout $= 0.2$)
  - Self-Attention Pooling Layer ($2 \times 128 \to 128$)
  - Projection Layer with LayerNorm and L2 Unit Normalization ($\|e\|_2 = 1.0$)
- **Loss Function**: `nn.CosineEmbeddingLoss(margin=0.2)`
  - Maximizes cosine similarity for semantically aligned segments ($y = 1$)
  - Enforces margin separation for contradictory or non-aligned segments ($y = -1$)

### B. Neural Consistency Classifier (`ml/models.py`)
- **Interaction Formulation**: Evaluates candidate pairs $(u, v)$ via dense feature concatenation:
  $$\text{Feature Vector} = [u \,\|\, v \,\|\, |u - v| \,\|\, u \odot v] \in \mathbb{R}^{512}$$
- **Hidden Layers**:
  - Linear($512 \to 256$) + BatchNorm1d + GELU + Dropout($0.3$)
  - Linear($256 \to 64$) + BatchNorm1d + GELU + Dropout($0.2$)
  - Linear($64 \to 2$) $\to$ Softmax probabilities: `[p_consistent, p_contradictory]`

### C. Explainability Layer (`ml/explainability.py`)
- Computes per-token attention weights from the `SelfAttentionPooling` module.
- Fuses attention rankings with `difflib.SequenceMatcher` to isolate specific contradictory tokens (e.g. `10 MB` vs `50 MB`, `Port 8080` vs `8443`, `Python 3.9` vs `3.12`).
- Renders inline `<mark class="highlight-conflict">` HTML tags for side-by-side visualization.

### D. Severity Scoring Engine (`ml/severity.py`)
Combines model confidence score with heuristic rules:
1. **Critical**: Numeric/capacity limits drift (`10MB` vs `50MB`), network port conflicts (`8080` vs `8443`), conflicting version constraints (`v1` vs `v2`), or model confidence $\ge 88\%$.
2. **Moderate**: Feature requirement or API route changes, model confidence $70\%\text{--}87\%$.
3. **Minor**: Stylistic or non-breaking procedural variations, confidence $< 70\%$.

---

## 🚀 4. Quick Start Guide

### Step 1: Install Dependencies
Ensure Python 3.10+ is installed, then run:

```bash
pip install -r requirements.txt
```

### Step 2: Train the ML Models from Scratch
Train both the Siamese BiLSTM embedder and the neural consistency classifier locally:

```bash
python train.py
```

This will:
1. Train the **Siamese BiLSTM Embedding Model** for 25 epochs.
2. Train the **Neural Consistency Classifier** for 30 epochs.
3. Save local checkpoints into `ml/checkpoints/`:
   - `vocab.json`
   - `embedding_model.pt`
   - `classifier_model.pt`
4. Run the **Academic Evaluation Suite** on the held-out test split, reporting:
   - Accuracy
   - Precision
   - Recall
   - F1-Score (Binary & Macro)
   - Confusion Matrix & Classification Report

### Step 3: Run the Web Application
Start the local Flask application server:

```bash
python run.py
```

Open your browser and navigate to:
```
http://127.0.0.1:5000
```

---

## 🖥️ 5. Application Screens & User Flow

1. **Login & Registration Page (`/login`)**:
   - Username/password authentication with Werkzeug password hashing.
   - **1-Click Reviewer Demo Login**: Click *"⚡ 1-Click Login as Project Reviewer / Examiner"* for instant evaluation.
2. **Dashboard (`/dashboard`)**:
   - Summary statistics cards: Total Audits, Average Consistency Score, Flagged Contradictions, Critical Issues.
   - History table listing past comparisons with status, date, score badges, and quick actions.
   - Pre-configured 1-click evaluation scenario cards.
3. **Document Upload Page (`/upload`)**:
   - Dual drag-and-drop file upload zones for Document A (Baseline) and Document B (Updated).
   - Full support for both **PDF** and **DOCX** technical documents.
   - Shortcut buttons to load preloaded sample files (Database Architecture PDF pair or Cloud SDK DOCX pair).
4. **Analysis / Loading Page (`/analyzing`)**:
   - Dynamic progress bar with live stage-by-stage pipeline checklist:
     1. Text Extraction $\to$ 2. Normalization & Chunking $\to$ 3. BiLSTM Embedding $\to$ 4. Cosine Matching $\to$ 5. Classification $\to$ 6. Explainability & Severity.
5. **Result Dashboard (`/results/<id>`)**:
   - Top score gauge displaying overall consistency percentage (0% to 100%).
   - Severity counters (Critical, Moderate, Minor, Clean).
   - Filter pills to view specific severity tiers.
   - Side-by-side section cards with **inline highlighted conflict keywords**, cosine similarity, model confidence, and automated explanation rationale.
6. **Visual Diff View (`/visual-diff/<id>`)**:
   - Dual-pane document viewer displaying original document context.
   - For **PDF**: PyMuPDF renders pages as high-resolution images with red/yellow bounding box rectangles drawn over contradictory sections.
   - For **DOCX**: Structured HTML representation with highlighted inconsistent paragraphs.
   - Inconsistency Navigator (`Prev Inconsistency` / `Next Inconsistency`) to jump directly to conflicting sections across both documents.
7. **Executive PDF Report Export (`/api/reports/<id>/export-pdf`)**:
   - Generates and downloads an audit report via ReportLab, formatted for executive review and academic documentation.

---

## 📂 6. Project Structure

```
doc-consistency-checker/
├── backend/
│   ├── app.py                     # Flask application factory & web routes
│   ├── routes/
│   │   ├── auth_routes.py         # /auth/login, /auth/register, /auth/demo-login
│   │   ├── analysis_routes.py     # /api/analyses, /api/upload-and-analyze, presets
│   │   ├── viewer_routes.py       # /api/viewer/<id>/doc/<role>/page/<num>
│   │   └── report_routes.py       # /api/reports/<id>/export-pdf
│   ├── services/
│   │   ├── extractor.py           # PyMuPDF & python-docx text & layout extractor
│   │   ├── visual_diff.py         # PDF image bounding-box renderer & DOCX parser
│   │   └── pdf_report.py          # ReportLab PDF report generator
│   └── uploads/                   # Uploaded user documents storage
├── database/
│   ├── db.py                      # SQLAlchemy engine & session factory (SQLite)
│   ├── models.py                  # User, Analysis, and Inconsistency models
│   └── doc_checker.db             # Local SQLite database file
├── data/
│   ├── sample_training_data.json  # 301 labeled technical sentence pairs
│   ├── generate_dataset.py        # Synthetic & technical dataset generator
│   ├── create_sample_docs.py      # Generator for sample PDF & DOCX test files
│   └── sample_docs/               # Ready-to-use sample PDFs and DOCX files
├── frontend/
│   ├── templates/
│   │   ├── base.html              # Shared layout, navbar, and footer
│   │   ├── login.html             # Login, signup, and demo examiner fast-track
│   │   ├── dashboard.html         # Audit history table, metrics, and presets
│   │   ├── upload.html            # Dual document drag-and-drop upload form
│   │   ├── analyzing.html         # Staged progress checklist during analysis
│   │   ├── results.html           # Result dashboard with side-by-side diff cards
│   │   └── visual_diff.html       # Dual-pane PDF/DOCX viewer with highlights
│   └── static/
│       ├── css/style.css          # Clean, modern, responsive styling
│       └── js/app.js              # Vanilla JS application and visual diff logic
├── ml/
│   ├── models.py                  # PyTorch DocumentationEmbeddingNet & ConsistencyClassifierNet
│   ├── tokenizer.py               # Custom vocabulary tokenizer (zero external deps)
│   ├── dataset.py                 # PyTorch Dataset and DataLoader with train/val/test splits
│   ├── train_embedding.py         # Trains BiLSTM Siamese network with CosineEmbeddingLoss
│   ├── train_classifier.py        # Trains Neural Consistency Classifier
│   ├── evaluate.py                # Computes Accuracy, Precision, Recall, F1 on test split
│   ├── explainability.py          # Per-token attention weights & difflib keyword extraction
│   ├── severity.py                # Rule-based and confidence severity evaluator
│   ├── pipeline.py                # Unified inference pipeline
│   └── checkpoints/               # Saved local model weights (vocab, .pt checkpoints)
├── train.py                       # Master ML training script
├── run.py                         # Flask server entry point
├── requirements.txt               # Dependencies list
└── README.md                      # Project documentation and guide
```

---

## 🎓 7. Academic Viva / Project Guide Talking Points

When presenting this project to examiners or academic guides, emphasize these design choices:

1. **Why Siamese BiLSTM before LLM/Classifier?**
   Comparing every section in Document A against every section in Document B directly with a dense interaction classifier scales as $O(N \times M)$. By computing dense 128-dimensional unit embeddings first, we perform fast vector cosine filtering, reducing millions of potential comparisons down to relevant semantic candidates.
2. **Why train from scratch instead of using pretrained Hugging Face models?**
   Pretrained models (like `all-MiniLM-L6-v2` or `BERT`) have billions of parameters trained on general web corpora, making them opaque "black boxes" that require substantial disk space and memory. By designing and training our own BiLSTM and interactive classifier from randomly initialized weights on technical pairs, we own the entire weight tensor pipeline, can inspect every gradient, and operate 100% locally on standard laptops without GPU or Internet.
3. **How does the Explainability Layer work without attention maps from massive transformers?**
   Our `SelfAttentionPooling` layer explicitly parameterizes token importance:
   $$\alpha_i = \frac{\exp(w^T \tanh(W h_i))}{\sum_j \exp(w^T \tanh(W h_j))}$$
   By surfacing $\alpha_i$, the model ranks which tokens contributed most heavily to the representation. Combined with word-level sequence matching, this precisely identifies why a requirement was flagged as contradictory.
4. **How are original layouts preserved in the Visual Diff View?**
   Instead of displaying stripped plain text, `PyMuPDF` extracts the exact bounding box rectangles `(x0, y0, x1, y1)` of every text block on the PDF canvas. When a contradiction is flagged, our backend renders the original PDF page to a PNG and overlays a semi-transparent colored highlight box directly on the page coordinates.
