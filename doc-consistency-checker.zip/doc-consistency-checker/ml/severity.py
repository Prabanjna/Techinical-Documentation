"""
Severity Scoring Utility for Technical Documentation Inconsistencies.
Combines classifier confidence score with deterministic heuristic rules:
- Differing numbers / limits (e.g. 10 MB vs 50 MB, Port 8080 vs 8443)
- Differing versions (e.g. Python 3.9 vs 3.12, v1.0 vs v2.0)
- Differing endpoints or HTTP methods (GET vs POST, /v1 vs /v2)
- High neural confidence thresholding
Assigns: Critical / Moderate / Minor.
"""

import re

class SeverityScorer:
    # Common regex patterns for technical documentation specifications
    NUMERIC_PATTERN = re.compile(r'\b\d+(?:\.\d+)?\b')
    VERSION_PATTERN = re.compile(r'\bv?\d+\.\d+(?:\.\d+)?\b', re.IGNORECASE)
    PORT_PATTERN = re.compile(r'\b(?:port\s*[:=]?\s*)(\d{2,5})\b', re.IGNORECASE)
    SIZE_LIMIT_PATTERN = re.compile(r'\b(\d+(?:\.\d+)?)\s*(?:mb|gb|kb|ms|s|seconds|bytes|nodes|replicas|req/min|rpm)\b', re.IGNORECASE)
    HTTP_METHOD_PATTERN = re.compile(r'\b(GET|POST|PUT|DELETE|PATCH)\b')
    ENDPOINT_PATTERN = re.compile(r'(/[a-zA-Z0-9_\-\./]+)')

    @classmethod
    def evaluate_severity(cls, text_a: str, text_b: str, confidence: float, is_contradictory: bool) -> tuple[str, list[str]]:
        """
        Evaluates severity level:
        Returns:
            severity: 'Critical' | 'Moderate' | 'Minor' | 'None'
            reasons: list of strings explaining why this severity was assigned
        """
        if not is_contradictory:
            return "None", ["Specifications are semantically consistent."]

        reasons = []
        score_weight = 0

        # Rule 1: Version mismatch (e.g., Python 3.9 vs 3.12, v1.2 vs v2.0)
        vers_a = set(cls.VERSION_PATTERN.findall(text_a))
        vers_b = set(cls.VERSION_PATTERN.findall(text_b))
        if vers_a and vers_b and (vers_a != vers_b):
            score_weight += 3
            reasons.append(f"Conflicting version numbers detected: '{', '.join(vers_a)}' vs '{', '.join(vers_b)}'.")

        # Rule 2: Quantitative / Size / Port limits mismatch (e.g., 10MB vs 50MB, Port 8080 vs 8443)
        limits_a = set([m.lower() for m in cls.SIZE_LIMIT_PATTERN.findall(text_a)])
        limits_b = set([m.lower() for m in cls.SIZE_LIMIT_PATTERN.findall(text_b)])
        if limits_a and limits_b and (limits_a != limits_b):
            score_weight += 3
            reasons.append(f"Divergent capacity/threshold limits detected: '{', '.join(limits_a)}' vs '{', '.join(limits_b)}'.")

        ports_a = set(cls.PORT_PATTERN.findall(text_a))
        ports_b = set(cls.PORT_PATTERN.findall(text_b))
        if ports_a and ports_b and (ports_a != ports_b):
            score_weight += 3
            reasons.append(f"Conflicting network port bindings: '{', '.join(ports_a)}' vs '{', '.join(ports_b)}'.")

        # Rule 3: General numbers mismatch
        nums_a = set(cls.NUMERIC_PATTERN.findall(text_a))
        nums_b = set(cls.NUMERIC_PATTERN.findall(text_b))
        num_diff = (nums_a ^ nums_b)
        if num_diff and len(num_diff) >= 2 and not (vers_a or limits_a or ports_a):
            score_weight += 2
            reasons.append(f"Discrepant numerical parameters detected ({', '.join(list(num_diff)[:4])}).")

        # Rule 4: Endpoint / HTTP method drift
        endpoints_a = set(cls.ENDPOINT_PATTERN.findall(text_a))
        endpoints_b = set(cls.ENDPOINT_PATTERN.findall(text_b))
        if endpoints_a and endpoints_b and (endpoints_a != endpoints_b):
            score_weight += 2
            reasons.append("API endpoint paths have diverged without backward-compatibility mapping.")

        methods_a = set(cls.HTTP_METHOD_PATTERN.findall(text_a))
        methods_b = set(cls.HTTP_METHOD_PATTERN.findall(text_b))
        if methods_a and methods_b and (methods_a != methods_b):
            score_weight += 2
            reasons.append(f"HTTP verbs conflict: '{', '.join(methods_a)}' vs '{', '.join(methods_b)}'.")

        # Rule 5: High confidence neural prediction factor
        if confidence >= 88.0:
            score_weight += 2
            reasons.append(f"Neural consistency classifier indicates strong contradiction certainty ({confidence}%).")
        elif confidence >= 72.0:
            score_weight += 1

        # Classify based on accumulated score weight
        if score_weight >= 3:
            severity = "Critical"
        elif score_weight >= 2 or confidence >= 75.0:
            severity = "Moderate"
        else:
            severity = "Minor"

        if not reasons:
            reasons.append("Semantic and procedural divergence identified across documentation text.")

        return severity, reasons
