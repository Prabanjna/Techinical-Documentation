"""
Evaluation Script for Technical Documentation Consistency Checker.
Calculates Accuracy, Precision, Recall, and F1-score on the held-out test split.
Outputs academic performance metrics and sample predictions.
"""

import os
import sys
import torch
import numpy as np
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, classification_report

from ml.tokenizer import CustomTokenizer
from ml.models import DocumentationEmbeddingNet, ConsistencyClassifierNet
from ml.dataset import load_dataset, split_dataset, SentencePairDataset

if sys.stdout and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

CHECKPOINT_DIR = os.path.join(os.path.dirname(__file__), "checkpoints")

def evaluate_models(data_path: str = None):
    if data_path is None:
        data_path = os.path.join(os.path.dirname(__file__), "..", "data", "sample_training_data.json")

    print("=" * 65)
    print("[*] Evaluating Custom ML Models on Held-Out Test Split")
    print("=" * 65)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # 1. Load Tokenizer & Models
    vocab_path = os.path.join(CHECKPOINT_DIR, "vocab.json")
    emb_path = os.path.join(CHECKPOINT_DIR, "embedding_model.pt")
    clf_path = os.path.join(CHECKPOINT_DIR, "classifier_model.pt")

    if not (os.path.exists(vocab_path) and os.path.exists(emb_path) and os.path.exists(clf_path)):
        raise FileNotFoundError("Checkpoints missing! Please run train_embedding.py and train_classifier.py first.")

    tokenizer = CustomTokenizer.load(vocab_path)

    emb_model = DocumentationEmbeddingNet(
        vocab_size=tokenizer.vocab_size,
        embed_dim=128,
        hidden_dim=128,
        out_dim=128
    ).to(device)
    emb_model.load_state_dict(torch.load(emb_path, map_location=device))
    emb_model.eval()

    classifier = ConsistencyClassifierNet(embed_dim=128, num_classes=2).to(device)
    classifier.load_state_dict(torch.load(clf_path, map_location=device))
    classifier.eval()

    # 2. Load held-out test data
    data = load_dataset(data_path)
    _, _, test_data = split_dataset(data, train_ratio=0.8, val_ratio=0.1, seed=42)
    test_ds = SentencePairDataset(test_data, tokenizer, max_len=64)

    y_true = []
    y_pred = []
    y_conf = []

    with torch.no_grad():
        for i in range(len(test_ds)):
            item = test_ds[i]
            ids1 = item["ids1"].unsqueeze(0).to(device)
            mask1 = item["mask1"].unsqueeze(0).to(device)
            ids2 = item["ids2"].unsqueeze(0).to(device)
            mask2 = item["mask2"].unsqueeze(0).to(device)
            target = item["label"].item()

            emb1 = emb_model(ids1, mask1)
            emb2 = emb_model(ids2, mask2)

            pred_class, confidence, _ = classifier.predict(emb1, emb2)

            y_true.append(target)
            y_pred.append(pred_class)
            y_conf.append(confidence)

    # 3. Compute Metrics
    acc = accuracy_score(y_true, y_pred)
    prec = precision_score(y_true, y_pred, average="binary", zero_division=0)
    rec = recall_score(y_true, y_pred, average="binary", zero_division=0)
    f1 = f1_score(y_true, y_pred, average="binary", zero_division=0)
    f1_macro = f1_score(y_true, y_pred, average="macro", zero_division=0)
    cm = confusion_matrix(y_true, y_pred)

    print(f"Total Test Samples Evaluated: {len(test_data)}")
    print(f"Test Accuracy  : {acc * 100:.2f}%")
    print(f"Precision      : {prec * 100:.2f}%")
    print(f"Recall         : {rec * 100:.2f}%")
    print(f"F1-Score (Bin) : {f1 * 100:.2f}%")
    print(f"F1-Score (Mac) : {f1_macro * 100:.2f}%")
    print("\nConfusion Matrix:")
    print(f"  [TN={cm[0][0]:2d}  FP={cm[0][1]:2d}]  (Consistent: 0)")
    print(f"  [FN={cm[1][0]:2d}  TP={cm[1][1]:2d}]  (Contradictory: 1)")

    print("\nDetailed Classification Report:")
    target_names = ["Consistent (0)", "Contradictory (1)"]
    print(classification_report(y_true, y_pred, target_names=target_names, digits=4))

    # 4. Sample Test Predictions
    print("=" * 65)
    print("[*] Sample Test Pair Inferences:")
    print("=" * 65)
    for idx in range(min(5, len(test_data))):
        item = test_data[idx]
        actual = "Consistent" if y_true[idx] == 0 else "Contradictory"
        pred = "Consistent" if y_pred[idx] == 0 else "Contradictory"
        status = "[PASS]" if y_true[idx] == y_pred[idx] else "[FAIL]"
        
        print(f"{status} Sample #{idx + 1} ({item.get('domain', 'Tech')})")
        print(f"  Doc A: \"{item['sentence1']}\"")
        print(f"  Doc B: \"{item['sentence2']}\"")
        print(f"  Actual: {actual} | Predicted: {pred} | Confidence: {y_conf[idx] * 100:.1f}%")
        print("-" * 65)

    return {
        "accuracy": acc,
        "precision": prec,
        "recall": rec,
        "f1": f1,
        "f1_macro": f1_macro,
        "confusion_matrix": cm.tolist()
    }

if __name__ == "__main__":
    evaluate_models()
