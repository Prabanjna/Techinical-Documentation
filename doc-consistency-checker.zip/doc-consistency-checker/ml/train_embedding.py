"""
Training Script for DocumentationEmbeddingNet.
Trains a Siamese Dual-Encoder BiLSTM from scratch with randomly initialized weights
using CosineEmbeddingLoss. Zero pretrained models or external AI APIs.
"""

import os
import sys
import torch
import torch.nn as nn
import torch.optim as optim
from ml.tokenizer import CustomTokenizer
from ml.models import DocumentationEmbeddingNet
from ml.dataset import load_dataset, split_dataset, get_dataloaders

if sys.stdout and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

CHECKPOINT_DIR = os.path.join(os.path.dirname(__file__), "checkpoints")
os.makedirs(CHECKPOINT_DIR, exist_ok=True)

def train_embedding_model(
    data_path: str,
    epochs: int = 25,
    batch_size: int = 16,
    lr: float = 1e-3,
    margin: float = 0.2
):
    print("=" * 60)
    print("[*] Training Custom Siamese Embedding Model from Scratch")
    print("=" * 60)

    # 1. Load data
    data = load_dataset(data_path)
    train_data, val_data, test_data = split_dataset(data, train_ratio=0.8, val_ratio=0.1, seed=42)
    print(f"Dataset: Total={len(data)}, Train={len(train_data)}, Val={len(val_data)}, Test={len(test_data)}")

    # 2. Build vocabulary on training sentences
    all_sentences = []
    for item in train_data:
        all_sentences.append(item["sentence1"])
        all_sentences.append(item["sentence2"])

    tokenizer = CustomTokenizer(max_len=64)
    tokenizer.fit(all_sentences, min_freq=1)
    vocab_path = os.path.join(CHECKPOINT_DIR, "vocab.json")
    tokenizer.save(vocab_path)
    print(f"Built Custom Vocabulary: {tokenizer.vocab_size} tokens saved to {vocab_path}")

    # 3. Create DataLoaders
    train_loader, val_loader, _ = get_dataloaders(
        train_data, val_data, test_data, tokenizer, batch_size=batch_size
    )

    # 4. Initialize Network from Scratch (Random Weights)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Executing training on: {device}")

    model = DocumentationEmbeddingNet(
        vocab_size=tokenizer.vocab_size,
        embed_dim=128,
        hidden_dim=128,
        out_dim=128
    ).to(device)

    criterion = nn.CosineEmbeddingLoss(margin=margin)
    optimizer = optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-4)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)

    best_val_loss = float("inf")
    model_path = os.path.join(CHECKPOINT_DIR, "embedding_model.pt")

    for epoch in range(1, epochs + 1):
        model.train()
        total_loss = 0.0

        for batch in train_loader:
            ids1 = batch["ids1"].to(device)
            mask1 = batch["mask1"].to(device)
            ids2 = batch["ids2"].to(device)
            mask2 = batch["mask2"].to(device)
            
            # Map labels: 0 (Consistent) -> 1.0, 1 (Contradictory) -> -1.0
            labels = batch["label"].to(device)
            target = torch.where(labels == 0, 1.0, -1.0)

            optimizer.zero_grad()
            emb1 = model(ids1, mask1)
            emb2 = model(ids2, mask2)

            loss = criterion(emb1, emb2, target)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            optimizer.step()

            total_loss += loss.item()

        scheduler.step()
        avg_train_loss = total_loss / len(train_loader)

        # Validation
        model.eval()
        val_loss = 0.0
        with torch.no_grad():
            for batch in val_loader:
                ids1 = batch["ids1"].to(device)
                mask1 = batch["mask1"].to(device)
                ids2 = batch["ids2"].to(device)
                mask2 = batch["mask2"].to(device)
                labels = batch["label"].to(device)
                target = torch.where(labels == 0, 1.0, -1.0)

                emb1 = model(ids1, mask1)
                emb2 = model(ids2, mask2)
                val_loss += criterion(emb1, emb2, target).item()

        avg_val_loss = val_loss / len(val_loader) if len(val_loader) > 0 else 0.0

        if epoch % 5 == 0 or epoch == epochs:
            print(f"Epoch {epoch:2d}/{epochs:2d} | Train Loss: {avg_train_loss:.4f} | Val Loss: {avg_val_loss:.4f}")

        if avg_val_loss < best_val_loss:
            best_val_loss = avg_val_loss
            torch.save(model.state_dict(), model_path)

    print(f"[+] Embedding Model Checkpoint successfully saved to: {model_path}")
    return model, tokenizer

if __name__ == "__main__":
    default_data = os.path.join(os.path.dirname(__file__), "..", "data", "sample_training_data.json")
    train_embedding_model(default_data)
