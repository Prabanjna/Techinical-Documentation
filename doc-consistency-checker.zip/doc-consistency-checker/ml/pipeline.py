"""
Inference Pipeline for Technical Documentation Consistency Checker.
Coordinates text chunk embedding, semantic candidate alignment via cosine similarity,
neural contradiction classification, per-token explainability, and rule-based severity scoring.
Zero external AI APIs or pretrained models.
"""

import os
import torch
import numpy as np
from ml.tokenizer import CustomTokenizer
from ml.models import DocumentationEmbeddingNet, ConsistencyClassifierNet
from ml.explainability import ExplainabilityEngine
from ml.severity import SeverityScorer

CHECKPOINT_DIR = os.path.join(os.path.dirname(__file__), "checkpoints")

class ConsistencyPipeline:
    def __init__(self, checkpoint_dir: str = CHECKPOINT_DIR):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.checkpoint_dir = checkpoint_dir
        self.tokenizer = None
        self.emb_model = None
        self.classifier = None
        self.explainability = None
        self._load_artifacts()

    def _load_artifacts(self):
        vocab_path = os.path.join(self.checkpoint_dir, "vocab.json")
        emb_path = os.path.join(self.checkpoint_dir, "embedding_model.pt")
        clf_path = os.path.join(self.checkpoint_dir, "classifier_model.pt")

        if not (os.path.exists(vocab_path) and os.path.exists(emb_path) and os.path.exists(clf_path)):
            raise FileNotFoundError(
                f"Model weights or vocab missing in {self.checkpoint_dir}. Train models first using train.py!"
            )

        # 1. Load Tokenizer
        self.tokenizer = CustomTokenizer.load(vocab_path)

        # 2. Load Embedding Model
        self.emb_model = DocumentationEmbeddingNet(
            vocab_size=self.tokenizer.vocab_size,
            embed_dim=128,
            hidden_dim=128,
            out_dim=128
        ).to(self.device)
        self.emb_model.load_state_dict(torch.load(emb_path, map_location=self.device))
        self.emb_model.eval()

        # 3. Load Classifier Model
        self.classifier = ConsistencyClassifierNet(embed_dim=128, num_classes=2).to(self.device)
        self.classifier.load_state_dict(torch.load(clf_path, map_location=self.device))
        self.classifier.eval()

        # 4. Initialize Explainability Engine
        self.explainability = ExplainabilityEngine(tokenizer=self.tokenizer, emb_model=self.emb_model)

    def embed_text(self, text: str) -> torch.Tensor:
        """Embeds a single string into a normalized 128-dimensional PyTorch tensor."""
        ids, mask = self.tokenizer.encode(text, max_len=64)
        ids = ids.unsqueeze(0).to(self.device)
        mask = mask.unsqueeze(0).to(self.device)
        with torch.no_grad():
            emb = self.emb_model(ids, mask)
        return emb

    def embed_chunks(self, chunks: list[dict]) -> list[dict]:
        """
        Computes embeddings for a list of chunk dictionaries.
        Each chunk dict has keys: 'id', 'title', 'text', and optional metadata.
        Adds 'embedding' key with 1D numpy array.
        """
        if not chunks:
            return []

        batch_ids = []
        batch_masks = []
        for c in chunks:
            ids, mask = self.tokenizer.encode(c["text"], max_len=64)
            batch_ids.append(ids)
            batch_masks.append(mask)

        batch_ids = torch.stack(batch_ids).to(self.device)
        batch_masks = torch.stack(batch_masks).to(self.device)

        with torch.no_grad():
            embeddings = self.emb_model(batch_ids, batch_masks).cpu().numpy()

        for i, c in enumerate(chunks):
            c["embedding"] = embeddings[i]

        return chunks

    def evaluate_pair(self, text_a: str, text_b: str) -> dict:
        """
        Evaluates a single pair of documentation excerpts for consistency/contradiction,
        extracts per-token explainability highlights, and assigns severity rating.
        """
        emb_a = self.embed_text(text_a)
        emb_b = self.embed_text(text_b)

        # Cosine similarity in [0, 1]
        raw_dot = float(torch.sum(emb_a * emb_b).item())
        cosine_sim = max(0.0, min(1.0, (raw_dot + 1.0) / 2.0))

        pred_class, confidence, probs = self.classifier.predict(emb_a, emb_b)
        is_contradictory = (pred_class == 1)
        conf_pct = round(confidence * 100, 1)

        # Severity evaluation
        severity, severity_reasons = SeverityScorer.evaluate_severity(
            text_a, text_b, conf_pct, is_contradictory
        )

        # Explainability analysis
        exp_res = self.explainability.explain_pair(text_a, text_b, is_contradictory)

        return {
            "is_contradictory": is_contradictory,
            "prediction_label": "Contradictory" if is_contradictory else "Consistent",
            "confidence": conf_pct,
            "similarity_score": round(cosine_sim * 100, 1),
            "probabilities": {
                "consistent": round(probs[0] * 100, 1),
                "contradictory": round(probs[1] * 100, 1)
            },
            "severity": severity,
            "severity_reasons": severity_reasons,
            "influential_words_a": exp_res["influential_words_a"],
            "influential_words_b": exp_res["influential_words_b"],
            "highlighted_text_a": exp_res["highlighted_text_a"],
            "highlighted_text_b": exp_res["highlighted_text_b"]
        }

    def analyze_documents(
        self,
        doc_a_chunks: list[dict],
        doc_b_chunks: list[dict],
        similarity_threshold: float = 0.28
    ) -> dict:
        """
        Compares two documents represented as chunk lists:
        1. Embeds chunks from Doc A and Doc B.
        2. Pairwise candidate alignment using cosine similarity.
        3. Neural consistency classification for each aligned pair.
        4. Explainability & severity computation.
        5. Aggregate summary stats.
        """
        if not doc_a_chunks or not doc_b_chunks:
            return {
                "overall_consistency_score": 100.0,
                "total_comparisons": 0,
                "contradictions_count": 0,
                "consistent_count": 0,
                "critical_count": 0,
                "moderate_count": 0,
                "minor_count": 0,
                "comparisons": []
            }

        # Embed all chunks
        self.embed_chunks(doc_a_chunks)
        self.embed_chunks(doc_b_chunks)

        comparisons = []
        contradictions_count = 0
        consistent_count = 0
        critical_count = 0
        moderate_count = 0
        minor_count = 0

        # Match each chunk in Doc A with candidate chunks in Doc B
        for chunk_a in doc_a_chunks:
            emb_a_vec = chunk_a["embedding"]
            best_candidates = []

            for chunk_b in doc_b_chunks:
                emb_b_vec = chunk_b["embedding"]
                raw_dot = float(np.dot(emb_a_vec, emb_b_vec))
                sim = max(0.0, min(1.0, (raw_dot + 1.0) / 2.0))

                if sim >= similarity_threshold:
                    best_candidates.append((sim, chunk_b))

            # Sort by similarity descending, take top match
            best_candidates.sort(key=lambda x: x[0], reverse=True)
            matched = best_candidates[:1] if best_candidates else []

            for sim, chunk_b in matched:
                eval_res = self.evaluate_pair(chunk_a["text"], chunk_b["text"])
                is_contra = eval_res["is_contradictory"]

                if is_contra:
                    contradictions_count += 1
                    if eval_res["severity"] == "Critical":
                        critical_count += 1
                    elif eval_res["severity"] == "Moderate":
                        moderate_count += 1
                    else:
                        minor_count += 1
                else:
                    consistent_count += 1

                # Generate structured rationale
                explanation = self._build_explanation(chunk_a, chunk_b, eval_res)

                comparisons.append({
                    "section_a_id": chunk_a["id"],
                    "section_a_title": chunk_a.get("title", f"Section {chunk_a['id']}"),
                    "section_a_text": chunk_a["text"],
                    "page_a": chunk_a.get("page", 1),
                    "bbox_a": chunk_a.get("bbox", None),
                    "para_idx_a": chunk_a.get("para_idx", None),

                    "section_b_id": chunk_b["id"],
                    "section_b_title": chunk_b.get("title", f"Section {chunk_b['id']}"),
                    "section_b_text": chunk_b["text"],
                    "page_b": chunk_b.get("page", 1),
                    "bbox_b": chunk_b.get("bbox", None),
                    "para_idx_b": chunk_b.get("para_idx", None),

                    "similarity_score": round(sim * 100, 1),
                    "confidence": eval_res["confidence"],
                    "is_contradictory": is_contra,
                    "prediction_label": eval_res["prediction_label"],
                    "severity": eval_res["severity"],
                    "severity_reasons": eval_res["severity_reasons"],
                    "influential_words_a": eval_res["influential_words_a"],
                    "influential_words_b": eval_res["influential_words_b"],
                    "highlighted_text_a": eval_res["highlighted_text_a"],
                    "highlighted_text_b": eval_res["highlighted_text_b"],
                    "explanation": explanation
                })

        total_pairs = len(comparisons)
        if total_pairs > 0:
            consistency_score = round((consistent_count / total_pairs) * 100, 1)
        else:
            consistency_score = 100.0

        return {
            "overall_consistency_score": consistency_score,
            "total_comparisons": total_pairs,
            "contradictions_count": contradictions_count,
            "consistent_count": consistent_count,
            "critical_count": critical_count,
            "moderate_count": moderate_count,
            "minor_count": minor_count,
            "comparisons": comparisons
        }

    def _build_explanation(self, chunk_a: dict, chunk_b: dict, eval_res: dict) -> str:
        title_a = chunk_a.get("title", "Doc A Section")
        title_b = chunk_b.get("title", "Doc B Section")
        is_contra = eval_res["is_contradictory"]
        conf = eval_res["confidence"]
        sev = eval_res["severity"]
        reasons = eval_res.get("severity_reasons", [])

        if is_contra:
            reason_str = " ".join(reasons)
            return (
                f"[{sev} Inconsistency] Neural classifier flagged conflicting requirements between "
                f"'{title_a}' and '{title_b}' with {conf}% confidence. {reason_str}"
            )
        else:
            return (
                f"Specifications between '{title_a}' and '{title_b}' are mutually consistent "
                f"({conf}% alignment confidence)."
            )
