"""
Explainability utility for Technical Documentation Consistency Checker.
Extracts top influential words/phrases from contradictory pairs using
per-token neural attention weights with difflib sequence matching as a complementary fallback.
"""

import re
import difflib
import torch

class ExplainabilityEngine:
    def __init__(self, tokenizer=None, emb_model=None):
        self.tokenizer = tokenizer
        self.emb_model = emb_model

    def explain_pair(self, text_a: str, text_b: str, is_contradictory: bool = True) -> dict:
        """
        Analyzes two contradictory text snippets and returns:
        1. List of influential/conflicting tokens/phrases for text_a
        2. List of influential/conflicting tokens/phrases for text_b
        3. HTML highlighted versions of text_a and text_b
        """
        # 1. Token diffing using difflib for direct semantic discrepancy
        diff_a_spans, diff_b_spans = self._extract_diff_spans(text_a, text_b)
        
        # 2. If model and tokenizer available, compute token attention weights
        attn_a_words = []
        attn_b_words = []
        if self.tokenizer is not None and self.emb_model is not None:
            attn_a_words = self._extract_high_attention_tokens(text_a)
            attn_b_words = self._extract_high_attention_tokens(text_b)

        # Merge influential tokens: union of diff words and high attention tokens
        influential_a = list(dict.fromkeys(diff_a_spans + [w for w in attn_a_words if w.lower() in text_a.lower()]))[:8]
        influential_b = list(dict.fromkeys(diff_b_spans + [w for w in attn_b_words if w.lower() in text_b.lower()]))[:8]

        # Generate inline HTML highlights
        highlighted_a = self.render_highlights(text_a, influential_a, badge_class="highlight-a")
        highlighted_b = self.render_highlights(text_b, influential_b, badge_class="highlight-b")

        return {
            "influential_words_a": influential_a,
            "influential_words_b": influential_b,
            "highlighted_text_a": highlighted_a,
            "highlighted_text_b": highlighted_b,
            "diff_keywords": list(set(diff_a_spans + diff_b_spans))
        }

    def _extract_diff_spans(self, text_a: str, text_b: str) -> tuple[list[str], list[str]]:
        """
        Uses word-level sequence matching to find replacement or inserted/deleted segments.
        Prioritizes numbers, technical parameters, and version strings.
        """
        words_a = re.findall(r'\b[\w\.\-/:]+\b', text_a)
        words_b = re.findall(r'\b[\w\.\-/:]+\b', text_b)

        matcher = difflib.SequenceMatcher(None, [w.lower() for w in words_a], [w.lower() for w in words_b])
        
        diff_a = []
        diff_b = []

        for tag, i1, i2, j1, j2 in matcher.get_opcodes():
            if tag in ('replace', 'delete'):
                for word in words_a[i1:i2]:
                    # Filter out purely generic stopwords unless they carry negations
                    if self._is_salient_token(word):
                        diff_a.append(word)
            if tag in ('replace', 'insert'):
                for word in words_b[j1:j2]:
                    if self._is_salient_token(word):
                        diff_b.append(word)

        return diff_a, diff_b

    def _is_salient_token(self, token: str) -> bool:
        """Determines if a token is informative for inconsistency explainability."""
        stopwords = {
            "the", "is", "are", "was", "were", "and", "or", "in", "on", "at", "to", "for", 
            "with", "by", "of", "from", "that", "this", "these", "those", "it", "its", "as",
            "an", "a", "be", "been", "being", "have", "has", "had", "do", "does", "did"
        }
        low = token.lower()
        if low in stopwords:
            return False
        # High value: contains digits, punctuation, or length > 2
        if any(char.isdigit() for char in token):
            return True
        return len(token) > 2

    def _extract_high_attention_tokens(self, text: str, top_k: int = 4) -> list[str]:
        """Runs embedding encoder with attention pooling and extracts tokens with top weights."""
        try:
            device = next(self.emb_model.parameters()).device
            ids, mask = self.tokenizer.encode(text, max_len=64)
            ids = ids.unsqueeze(0).to(device)
            mask = mask.unsqueeze(0).to(device)

            self.emb_model.eval()
            with torch.no_grad():
                _, attn_weights = self.emb_model(ids, mask, return_attention=True)

            weights = attn_weights.squeeze(0).cpu().numpy()
            id_list = ids.squeeze(0).cpu().tolist()

            # Rank by weight, ignoring PAD(0), UNK(1)
            token_scores = []
            for token_id, weight in zip(id_list, weights):
                if token_id in (0, 1):
                    continue
                token_str = self.tokenizer.id_to_token.get(token_id, "")
                if self._is_salient_token(token_str):
                    token_scores.append((token_str, weight))

            token_scores.sort(key=lambda x: x[1], reverse=True)
            return [t[0] for t in token_scores[:top_k]]
        except Exception:
            return []

    def render_highlights(self, text: str, highlight_words: list[str], badge_class: str = "highlight-conflict") -> str:
        """
        Wraps matched target tokens in HTML <mark class="..."> tags safely.
        """
        if not highlight_words:
            return text

        # Sort longer phrases/words first to avoid partial collision
        sorted_words = sorted(set(highlight_words), key=len, reverse=True)
        highlighted = text

        for word in sorted_words:
            if not word.strip():
                continue
            # Word boundary regex with case preservation
            pattern = re.compile(rf'(?<!<mark class="{badge_class}">)\b({re.escape(word)})\b(?!</mark>)', re.IGNORECASE)
            highlighted = pattern.sub(rf'<mark class="{badge_class}">\1</mark>', highlighted)

        return highlighted
