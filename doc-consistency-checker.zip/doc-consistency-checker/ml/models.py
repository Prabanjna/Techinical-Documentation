"""
Neural Network Architectures for Technical Documentation Consistency Checker.
Trained strictly from randomly initialized weights locally with PyTorch.
Zero pretrained checkpoints or external APIs used.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F

class SelfAttentionPooling(nn.Module):
    """
    Self-attention pooling mechanism to compute a weighted representation
    of variable-length token sequences, ignoring padded tokens.
    """
    def __init__(self, hidden_dim: int):
        super().__init__()
        self.attention = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.Tanh(),
            nn.Linear(hidden_dim // 2, 1)
        )

    def forward(self, rnn_outputs: torch.Tensor, mask: torch.Tensor, return_weights: bool = False):
        """
        Args:
            rnn_outputs: Tensor of shape (batch_size, seq_len, hidden_dim)
            mask: Tensor of shape (batch_size, seq_len) with 1 for active tokens, 0 for pad
            return_weights: If True, returns (pooled, weights)
        Returns:
            pooled: Tensor of shape (batch_size, hidden_dim)
            weights (optional): Tensor of shape (batch_size, seq_len)
        """
        scores = self.attention(rnn_outputs).squeeze(-1)
        scores = scores.masked_fill(mask == 0, -1e9)
        weights = F.softmax(scores, dim=-1)  # (batch_size, seq_len)
        pooled = torch.sum(rnn_outputs * weights.unsqueeze(-1), dim=1)  # (batch_size, hidden_dim)
        
        if return_weights:
            return pooled, weights
        return pooled


class DocumentationEmbeddingNet(nn.Module):
    """
    BiLSTM-based Siamese Dual-Encoder Network that maps technical documentation
    chunks into a dense, normalized vector space (128-dimensional).
    """
    def __init__(self, vocab_size: int, embed_dim: int = 128, hidden_dim: int = 128, out_dim: int = 128):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=0)
        self.drop = nn.Dropout(p=0.2)
        
        # 2-layer Bidirectional LSTM
        self.lstm = nn.LSTM(
            input_size=embed_dim,
            hidden_size=hidden_dim,
            num_layers=2,
            batch_first=True,
            bidirectional=True,
            dropout=0.2
        )
        
        # BiLSTM produces 2 * hidden_dim features
        self.pooler = SelfAttentionPooling(hidden_dim * 2)
        self.proj = nn.Linear(hidden_dim * 2, out_dim)
        self.layer_norm = nn.LayerNorm(out_dim)

    def forward(self, input_ids: torch.Tensor, mask: torch.Tensor, return_attention: bool = False):
        """
        Encodes token sequence into a normalized unit vector embedding.
        Args:
            input_ids: (batch_size, seq_len)
            mask: (batch_size, seq_len)
            return_attention: whether to return per-token attention weights
        Returns:
            normalized_embeddings: (batch_size, out_dim)
            (optional) attn_weights: (batch_size, seq_len)
        """
        x = self.drop(self.embedding(input_ids))
        lstm_out, _ = self.lstm(x)
        if return_attention:
            pooled, attn_weights = self.pooler(lstm_out, mask, return_weights=True)
            projected = self.proj(pooled)
            normalized = F.normalize(self.layer_norm(projected), p=2, dim=-1)
            return normalized, attn_weights
            
        pooled = self.pooler(lstm_out, mask, return_weights=False)
        projected = self.proj(pooled)
        normalized = F.normalize(self.layer_norm(projected), p=2, dim=-1)
        return normalized


class ConsistencyClassifierNet(nn.Module):
    """
    Feedforward interaction classifier that evaluates semantic consistency vs contradiction
    between pairs of technical documentation chunk embeddings.
    Features: [u; v; |u - v|; u * v]
    """
    def __init__(self, embed_dim: int = 128, num_classes: int = 2):
        super().__init__()
        input_dim = embed_dim * 4  # Concatenated representation: u, v, diff, product
        
        self.classifier = nn.Sequential(
            nn.Linear(input_dim, 256),
            nn.BatchNorm1d(256),
            nn.GELU(),
            nn.Dropout(p=0.3),
            
            nn.Linear(256, 64),
            nn.BatchNorm1d(64),
            nn.GELU(),
            nn.Dropout(p=0.2),
            
            nn.Linear(64, num_classes)
        )

    def forward(self, emb_a: torch.Tensor, emb_b: torch.Tensor) -> torch.Tensor:
        """
        Args:
            emb_a: Tensor of shape (batch_size, embed_dim)
            emb_b: Tensor of shape (batch_size, embed_dim)
        Returns:
            logits: Tensor of shape (batch_size, num_classes)
        """
        diff = torch.abs(emb_a - emb_b)
        prod = emb_a * emb_b
        features = torch.cat([emb_a, emb_b, diff, prod], dim=-1)
        return self.classifier(features)

    def predict(self, emb_a: torch.Tensor, emb_b: torch.Tensor) -> tuple[int, float, list[float]]:
        """
        Utility for single-pair inference.
        Returns:
            predicted_class (0: Consistent, 1: Contradictory)
            confidence (float between 0.0 and 1.0)
            probabilities (list of [p_consistent, p_contradictory])
        """
        self.eval()
        with torch.no_grad():
            if emb_a.dim() == 1:
                emb_a = emb_a.unsqueeze(0)
            if emb_b.dim() == 1:
                emb_b = emb_b.unsqueeze(0)
                
            logits = self.forward(emb_a, emb_b)
            probs = F.softmax(logits, dim=-1).squeeze(0).cpu().tolist()
            pred_class = int(torch.argmax(logits, dim=-1).item())
            confidence = float(probs[pred_class])
            return pred_class, confidence, probs
