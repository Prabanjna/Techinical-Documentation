"""
Training Script for ConsistencyClassifierNet.
Trains a Neural Interaction Classifier from scratch on labeled documentation sentence pairs.
Zero pretrained checkpoints or external APIs used.
"""

import os
import sys
import torch
import torch.nn as nn
import torch.optim as optim
from ml.tokenizer import CustomTokenizer
from ml.models import DocumentationEmbeddingNet, ConsistencyClassifierNet
from ml.dataset import load_dataset, split_dataset, get_dataloaders

if sys.stdout and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

CHECKPOINT_DIR = os.path.join(os.path.dirname(__file__), "checkpoints")

def train_classifier_model(
    data_path: str,
    epochs: int = 30,
    batch_size: int = 16,
    lr: float = 2e-3
):
    print("=" * 60)
    print("[*] Training Custom Consistency Classifier Network from Scratch")
    print("=" * 60)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Executing training on: {device}")

    # 1. Load Tokenizer & Vocab
    vocab_path = os.path.join(CHECKPOINT_DIR, "vocab.json")
    if not os.path.exists(vocab_path):
        raise FileNotFoundError(f"Vocabulary file not found at {vocab_path}. Run train_embedding.py first!")
    tokenizer = CustomTokenizer.load(vocab_path)

    # 2. Load Embedding Model
    emb_model_path = os.path.join(CHECKPOINT_DIR, "embedding_model.pt")
    if not os.path.exists(emb_model_path):
        raise FileNotFoundError(f"Embedding checkpoint not found at {emb_model_path}. Run train_embedding.py first!")

    emb_model = DocumentationEmbeddingNet(
        vocab_size=tokenizer.vocab_size,
        embed_dim=128,
        hidden_dim=128,
        out_dim=128
    ).to(device)
    emb_model.load_state_dict(torch.load(emb_model_path, map_location=device))
    emb_model.eval()
    for param in emb_model.parameters():
        param.requires_grad = False  # Freeze embedding encoder for stable classifier convergence

    # 3. Load Dataset
    data = load_dataset(data_path)
    train_data, val_data, test_data = split_dataset(data, train_ratio=0.8, val_ratio=0.1, seed=42)
    train_loader, val_loader, _ = get_dataloaders(
        train_data, val_data, test_data, tokenizer, batch_size=batch_size
    )

    # 4. Initialize Classifier Network (Random Weights)
    classifier = ConsistencyClassifierNet(embed_dim=128, num_classes=2).to(device)

    criterion = nn.CrossEntropyLoss()
    optimizer = optim.AdamW(classifier.parameters(), lr=lr, weight_decay=1e-3)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode="min", factor=0.5, patience=5)

    best_val_acc = 0.0
    classifier_path = os.path.join(CHECKPOINT_DIR, "classifier_model.pt")

    for epoch in range(1, epochs + 1):
        classifier.train()
        total_loss = 0.0
        correct = 0
        total = 0

        for batch in train_loader:
            ids1 = batch["ids1"].to(device)
            mask1 = batch["mask1"].to(device)
            ids2 = batch["ids2"].to(device)
            mask2 = batch["mask2"].to(device)
            labels = batch["label"].to(device)

            with torch.no_grad():
                emb1 = emb_model(ids1, mask1)
                emb2 = emb_model(ids2, mask2)

            optimizer.zero_grad()
            logits = classifier(emb1, emb2)
            loss = criterion(logits, labels)
            loss.backward()
            optimizer.step()

            total_loss += loss.item()
            preds = torch.argmax(logits, dim=-1)
            correct += (preds == labels).sum().item()
            total += labels.size(0)

        train_acc = (correct / total) * 100 if total > 0 else 0.0
        avg_train_loss = total_loss / len(train_loader)

        # Validation
        classifier.eval()
        val_loss = 0.0
        val_correct = 0
        val_total = 0

        with torch.no_grad():
            for batch in val_loader:
                ids1 = batch["ids1"].to(device)
                mask1 = batch["mask1"].to(device)
                ids2 = batch["ids2"].to(device)
                mask2 = batch["mask2"].to(device)
                labels = batch["label"].to(device)

                emb1 = emb_model(ids1, mask1)
                emb2 = emb_model(ids2, mask2)

                logits = classifier(emb1, emb2)
                loss = criterion(logits, labels)
                val_loss += loss.item()

                preds = torch.argmax(logits, dim=-1)
                val_correct += (preds == labels).sum().item()
                val_total += labels.size(0)

        avg_val_loss = val_loss / len(val_loader) if len(val_loader) > 0 else 0.0
        val_acc = (val_correct / val_total) * 100 if val_total > 0 else 0.0
        scheduler.step(avg_val_loss)

        if epoch % 5 == 0 or epoch == epochs:
            print(f"Epoch {epoch:2d}/{epochs:2d} | Train Acc: {train_acc:.1f}% (Loss: {avg_train_loss:.4f}) | Val Acc: {val_acc:.1f}% (Loss: {avg_val_loss:.4f})")

        if val_acc >= best_val_acc:
            best_val_acc = val_acc
            torch.save(classifier.state_dict(), classifier_path)

    print(f"[+] Classifier Checkpoint successfully saved to: {classifier_path} (Best Val Acc: {best_val_acc:.1f}%)")
    return classifier

if __name__ == "__main__":
    default_data = os.path.join(os.path.dirname(__file__), "..", "data", "sample_training_data.json")
    train_classifier_model(default_data)
