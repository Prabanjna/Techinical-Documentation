"""
PyTorch Dataset and DataLoader abstractions for training and evaluating
the Documentation Consistency models.
"""

import json
import random
import torch
from torch.utils.data import Dataset, DataLoader
from ml.tokenizer import CustomTokenizer

class SentencePairDataset(Dataset):
    def __init__(self, data: list[dict], tokenizer: CustomTokenizer, max_len: int = 64):
        self.data = data
        self.tokenizer = tokenizer
        self.max_len = max_len

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        item = self.data[idx]
        s1 = item["sentence1"]
        s2 = item["sentence2"]
        label = item["label"]  # 0: Consistent, 1: Contradictory

        ids1, mask1 = self.tokenizer.encode(s1, max_len=self.max_len)
        ids2, mask2 = self.tokenizer.encode(s2, max_len=self.max_len)

        return {
            "ids1": ids1,
            "mask1": mask1,
            "ids2": ids2,
            "mask2": mask2,
            "label": torch.tensor(label, dtype=torch.long),
            "sentence1": s1,
            "sentence2": s2,
            "domain": item.get("domain", "General"),
            "explanation": item.get("explanation", "")
        }


def load_dataset(json_path: str) -> list[dict]:
    with open(json_path, "r", encoding="utf-8") as f:
        return json.load(f)


def split_dataset(data: list[dict], train_ratio: float = 0.80, val_ratio: float = 0.10, seed: int = 42):
    """
    Deterministically splits data into train, val, and test subsets.
    """
    rng = random.Random(seed)
    shuffled = list(data)
    rng.shuffle(shuffled)

    n = len(shuffled)
    n_train = int(n * train_ratio)
    n_val = int(n * val_ratio)

    train_data = shuffled[:n_train]
    val_data = shuffled[n_train : n_train + n_val]
    test_data = shuffled[n_train + n_val :]

    return train_data, val_data, test_data


def get_dataloaders(
    train_data: list[dict],
    val_data: list[dict],
    test_data: list[dict],
    tokenizer: CustomTokenizer,
    batch_size: int = 16,
    max_len: int = 64
):
    train_ds = SentencePairDataset(train_data, tokenizer, max_len=max_len)
    val_ds = SentencePairDataset(val_data, tokenizer, max_len=max_len)
    test_ds = SentencePairDataset(test_data, tokenizer, max_len=max_len)

    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False)
    test_loader = DataLoader(test_ds, batch_size=batch_size, shuffle=False)

    return train_loader, val_loader, test_loader
