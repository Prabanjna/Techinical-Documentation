"""
Custom Tokenizer & Vocabulary Builder for Technical Documentation.
Built strictly from scratch without external tokenizers or pretrained assets.
"""

import json
import re
from collections import Counter
import torch

class CustomTokenizer:
    PAD_TOKEN = "<pad>"  # index 0
    UNK_TOKEN = "<unk>"  # index 1
    SOS_TOKEN = "<sos>"  # index 2
    EOS_TOKEN = "<eos>"  # index 3

    def __init__(self, max_len: int = 64):
        self.max_len = max_len
        self.word2idx = {}
        self.idx2word = {}
        self.vocab_size = 0
        self._init_special_tokens()

    def _init_special_tokens(self):
        special = [self.PAD_TOKEN, self.UNK_TOKEN, self.SOS_TOKEN, self.EOS_TOKEN]
        self.word2idx = {token: idx for idx, token in enumerate(special)}
        self.idx2word = {idx: token for idx, token in enumerate(special)}
        self.vocab_size = len(special)

    def tokenize_text(self, text: str) -> list[str]:
        """
        Tokenizes text into words, punctuation, version strings, numbers, and paths.
        Normalizes lowercase while preserving technical identifiers.
        """
        if not text:
            return []
        
        text = text.lower().strip()
        # Regex captures technical words, paths, version tags, and individual punctuation
        tokens = re.findall(r'[a-z0-9_\-\.\/:]+|[^\s\w]', text)
        return tokens

    def fit(self, texts: list[str], min_freq: int = 1):
        """
        Builds vocabulary from a collection of raw text strings.
        """
        counter = Counter()
        for text in texts:
            tokens = self.tokenize_text(text)
            counter.update(tokens)

        idx = len(self.word2idx)
        for word, count in counter.most_common():
            if count >= min_freq and word not in self.word2idx:
                self.word2idx[word] = idx
                self.idx2word[idx] = word
                idx += 1

        self.vocab_size = len(self.word2idx)
        return self

    def encode(self, text: str, max_len: int = None) -> tuple[torch.Tensor, torch.Tensor]:
        """
        Encodes text into a padded tensor of token indices and an attention mask.
        Returns:
            indices_tensor: torch.LongTensor of shape (max_len,)
            mask_tensor: torch.FloatTensor of shape (max_len,) with 1 for tokens, 0 for pad
        """
        limit = max_len or self.max_len
        tokens = self.tokenize_text(text)
        
        # Truncate if longer than max_len - 2 (to fit SOS and EOS)
        truncated = tokens[: limit - 2]
        sequence = [self.SOS_TOKEN] + truncated + [self.EOS_TOKEN]
        
        indices = [self.word2idx.get(tok, self.word2idx[self.UNK_TOKEN]) for tok in sequence]
        mask = [1.0] * len(indices)

        # Pad to max_len
        if len(indices) < limit:
            padding_len = limit - len(indices)
            indices += [self.word2idx[self.PAD_TOKEN]] * padding_len
            mask += [0.0] * padding_len
        else:
            indices = indices[:limit]
            mask = mask[:limit]

        return torch.tensor(indices, dtype=torch.long), torch.tensor(mask, dtype=torch.float)

    def decode(self, indices: list[int]) -> str:
        """
        Converts a list of token IDs back into human-readable text.
        """
        words = []
        for idx in indices:
            if idx in self.idx2word:
                word = self.idx2word[idx]
                if word not in (self.PAD_TOKEN, self.SOS_TOKEN, self.EOS_TOKEN):
                    words.append(word)
        return " ".join(words)

    def save(self, filepath: str):
        """Saves vocabulary configuration to JSON."""
        state = {
            "max_len": self.max_len,
            "word2idx": self.word2idx,
            "vocab_size": self.vocab_size
        }
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(state, f, indent=2, ensure_ascii=False)

    @classmethod
    def load(cls, filepath: str) -> "CustomTokenizer":
        """Loads vocabulary configuration from JSON."""
        with open(filepath, "r", encoding="utf-8") as f:
            state = json.load(f)
        
        tokenizer = cls(max_len=state.get("max_len", 64))
        tokenizer.word2idx = state["word2idx"]
        tokenizer.idx2word = {int(v): k for k, v in tokenizer.word2idx.items()}
        tokenizer.vocab_size = len(tokenizer.word2idx)
        return tokenizer
