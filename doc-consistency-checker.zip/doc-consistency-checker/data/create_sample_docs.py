"""
Generate realistic sample PDF and DOCX technical documents for end-to-end testing
of the consistency checker application.
"""

import os
from docx import Document
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, HRFlowable
from reportlab.lib import colors

DOCS_DIR = os.path.join(os.path.dirname(__file__), "sample_docs")
os.makedirs(DOCS_DIR, exist_ok=True)

def create_docx_v1():
    doc = Document()
    doc.add_heading("CloudSDK Platform Architecture & Specification (v1.0)", level=0)
    
    doc.add_heading("1. Runtime Environment & Prerequisites", level=1)
    doc.add_paragraph(
        "The application requires Python 3.9 or higher to execute all async background workers. "
        "Worker processes run on Linux x86_64 kernel 5.15 and higher as certified target platforms. "
        "The minimum Go compiler requirement is Go 1.16 for building the client SDK binaries."
    )
    
    doc.add_heading("2. Networking & Port Bindings", level=1)
    doc.add_paragraph(
        "The administrative control panel is exposed on port 8080 over plain unencrypted HTTP. "
        "The gRPC inter-service RPC listener binds to TCP port 50051. "
        "Prometheus metrics scraper connects to the /metrics route on port 9090."
    )
    
    doc.add_heading("3. Authentication & Access Security", level=1)
    doc.add_paragraph(
        "Client requests must include a valid Bearer token in the HTTP Authorization header. "
        "Session tokens expire after 24 hours of continuous inactivity. "
        "All public endpoints authenticate using pre-shared API keys passed in the X-API-Key header."
    )
    
    doc.add_heading("4. Gateway Quotas & Limits", level=1)
    doc.add_paragraph(
        "The upstream gateway enforces a strict HTTP request timeout of 30 seconds. "
        "Maximum allowable file upload payload is 10 Megabytes. "
        "Rate limits allow up to 1,000 requests per minute per authenticated API credential."
    )
    
    path = os.path.join(DOCS_DIR, "CloudSDK_Spec_v1.docx")
    doc.save(path)
    print(f"Created: {path}")

def create_docx_v2():
    doc = Document()
    doc.add_heading("CloudSDK Platform Architecture & Specification (v2.0)", level=0)
    
    doc.add_heading("1. Runtime Environment & Prerequisites", level=1)
    doc.add_paragraph(
        "Python 3.12 is the minimum supported interpreter; Python 3.9 reached end-of-life and is unsupported. "
        "The agent daemon supports 64-bit Linux kernels running version 5.15 or newer. "
        "The client SDK requires Go version 1.21 or later to support structured logging."
    )
    
    doc.add_heading("2. Networking & Port Bindings", level=1)
    doc.add_paragraph(
        "The admin portal is strictly accessible on port 8443 requiring TLS 1.3 encryption. "
        "Inter-service remote procedure calls communicate over port 50051 using gRPC. "
        "Application telemetry and Prometheus metrics are exposed via port 9090 at /metrics."
    )
    
    doc.add_heading("3. Authentication & Access Security", level=1)
    doc.add_paragraph(
        "Authentication is verified via the Authorization header formatted as 'Bearer <token>'. "
        "Idle session tokens are automatically invalidated after exactly 15 minutes of inactivity. "
        "Authentication is performed exclusively via Mutual TLS (mTLS) client certificates; API key headers are rejected."
    )
    
    doc.add_heading("4. Gateway Quotas & Limits", level=1)
    doc.add_paragraph(
        "Client HTTP requests will be terminated with gateway timeout after 5 seconds of latency. "
        "The file upload service accepts documents and attachments up to 100 Megabytes in size. "
        "Authenticated callers are restricted to a rate quota of 1,000 API requests each minute."
    )
    
    path = os.path.join(DOCS_DIR, "CloudSDK_Spec_v2.docx")
    doc.save(path)
    print(f"Created: {path}")

def create_pdf_v1():
    path = os.path.join(DOCS_DIR, "Database_Architecture_v1.pdf")
    doc = SimpleDocTemplate(path, pagesize=letter, rightMargin=40, leftMargin=40, topMargin=40, bottomMargin=40)
    styles = getSampleStyleSheet()
    story = []
    
    title_style = ParagraphStyle(
        'TitleStyle',
        parent=styles['Heading1'],
        fontSize=18,
        leading=22,
        textColor=colors.HexColor("#1e293b"),
        spaceAfter=12
    )
    heading_style = ParagraphStyle(
        'HeadingStyle',
        parent=styles['Heading2'],
        fontSize=13,
        leading=16,
        textColor=colors.HexColor("#3b82f6"),
        spaceBefore=14,
        spaceAfter=6
    )
    body_style = ParagraphStyle(
        'BodyStyle',
        parent=styles['Normal'],
        fontSize=10,
        leading=14,
        textColor=colors.HexColor("#334155"),
        spaceAfter=10
    )
    
    story.append(Paragraph("Enterprise Database Architecture Specification (Release 2023)", title_style))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#cbd5e1"), spaceAfter=12))
    
    story.append(Paragraph("Section 1: Clustering and High Availability", heading_style))
    story.append(Paragraph(
        "The production cluster uses PostgreSQL 16 with Read Committed transaction isolation. "
        "The database cluster requires a minimum of 3 primary nodes for consensus voting. "
        "Automated snapshot backups execute every 24 hours at 02:00 UTC.",
        body_style
    ))
    
    story.append(Paragraph("Section 2: Concurrency & Connection Pooling", heading_style))
    story.append(Paragraph(
        "Database connection pool maintains a maximum of 50 concurrent connections. "
        "Database connection pool timeout is configured to 10,000 milliseconds. "
        "Read queries are distributed across read-only replica instances using round-robin routing.",
        body_style
    ))
    
    story.append(Paragraph("Section 3: Storage & Indexing Engine", heading_style))
    story.append(Paragraph(
        "Database primary keys are 128-bit UUIDv4 identifiers generated on the client side. "
        "Indexes on user email columns use case-insensitive B-Tree indexing. "
        "Database migrations are applied automatically on application startup using Liquibase.",
        body_style
    ))
    
    doc.build(story)
    print(f"Created: {path}")

def create_pdf_v2():
    path = os.path.join(DOCS_DIR, "Database_Architecture_v2.pdf")
    doc = SimpleDocTemplate(path, pagesize=letter, rightMargin=40, leftMargin=40, topMargin=40, bottomMargin=40)
    styles = getSampleStyleSheet()
    story = []
    
    title_style = ParagraphStyle(
        'TitleStyle',
        parent=styles['Heading1'],
        fontSize=18,
        leading=22,
        textColor=colors.HexColor("#1e293b"),
        spaceAfter=12
    )
    heading_style = ParagraphStyle(
        'HeadingStyle',
        parent=styles['Heading2'],
        fontSize=13,
        leading=16,
        textColor=colors.HexColor("#3b82f6"),
        spaceBefore=14,
        spaceAfter=6
    )
    body_style = ParagraphStyle(
        'BodyStyle',
        parent=styles['Normal'],
        fontSize=10,
        leading=14,
        textColor=colors.HexColor("#334155"),
        spaceAfter=10
    )
    
    story.append(Paragraph("Enterprise Database Architecture Specification (Release 2024)", title_style))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#cbd5e1"), spaceAfter=12))
    
    story.append(Paragraph("Section 1: Clustering and High Availability", heading_style))
    story.append(Paragraph(
        "PostgreSQL 16 is deployed across production, configured with Read Committed isolation level. "
        "High-availability clustering requires an odd number of voting nodes, with at least 7 active replicas. "
        "Database volume snapshots are scheduled on a daily basis at 02:00 UTC.",
        body_style
    ))
    
    story.append(Paragraph("Section 2: Concurrency & Connection Pooling", heading_style))
    story.append(Paragraph(
        "The database connection pool allows up to 500 concurrent connections per worker node. "
        "Acquiring a connection from the database pool times out after 10 seconds. "
        "All database operations including SELECT queries must execute directly against the primary master instance.",
        body_style
    ))
    
    story.append(Paragraph("Section 3: Storage & Indexing Engine", heading_style))
    story.append(Paragraph(
        "Record primary keys use client-generated UUID version 4 string representations. "
        "Search queries on username utilize a PostgreSQL GIN index. "
        "Automatic database migrations at boot are strictly forbidden; schema updates run via manual CI pipelines.",
        body_style
    ))
    
    doc.build(story)
    print(f"Created: {path}")

if __name__ == "__main__":
    create_docx_v1()
    create_docx_v2()
    create_pdf_v1()
    create_pdf_v2()
    print("All sample documents successfully generated!")
