"""
Generate sample technical documentation dataset for training the custom embedding
and consistency classification neural networks from scratch.
Zero external AI APIs or pretrained models are used.
"""

import json
import os

DATASET = [
    # --- RUNTIME & LANGUAGE VERSIONS ---
    {
        "sentence1": "The application requires Python 3.9 or higher to execute all async background workers.",
        "sentence2": "Python 3.12 is the minimum supported interpreter; Python 3.9 reached end-of-life and is unsupported.",
        "label": 1,
        "domain": "Runtime",
        "explanation": "Conflicting minimum Python version requirements (Python 3.9 vs Python 3.12 minimum)."
    },
    {
        "sentence1": "All microservices run on Node.js 18 LTS runtime environment.",
        "sentence2": "The service runtime is built and validated strictly against Node.js 18 LTS releases.",
        "label": 0,
        "domain": "Runtime",
        "explanation": "Consistent specifications regarding Node.js 18 LTS runtime."
    },
    {
        "sentence1": "Microservices must be compiled using OpenJDK 17 with preview features disabled.",
        "sentence2": "Java 8 is the required compile target for all microservice binaries.",
        "label": 1,
        "domain": "Runtime",
        "explanation": "Contradiction in required Java compile versions (OpenJDK 17 vs Java 8)."
    },
    {
        "sentence1": "The backend service supports Ruby 3.2 and utilizes YJIT for just-in-time compilation.",
        "sentence2": "Production backend processes execute on Ruby 3.2 with the YJIT compiler activated.",
        "label": 0,
        "domain": "Runtime",
        "explanation": "Consistent statements confirming Ruby 3.2 with YJIT enabled."
    },
    {
        "sentence1": "The client SDK requires Go version 1.21 or later to support structured logging.",
        "sentence2": "The minimum Go compiler requirement is Go 1.16 for building the client SDK.",
        "label": 1,
        "domain": "Runtime",
        "explanation": "Discrepancy in minimum Go version requirement (1.21 vs 1.16)."
    },
    {
        "sentence1": "The agent daemon supports 64-bit Linux kernels running version 5.15 or newer.",
        "sentence2": "Linux x86_64 kernel 5.15 and higher are certified platforms for the agent daemon.",
        "label": 0,
        "domain": "Runtime",
        "explanation": "Consistent OS kernel architecture requirements."
    },
    {
        "sentence1": "The application requires .NET 8.0 SDK for compilation and container deployment.",
        "sentence2": "Legacy .NET Framework 4.8 is mandated for building and deploying this service.",
        "label": 1,
        "domain": "Runtime",
        "explanation": "Direct contradiction between modern .NET 8.0 and legacy .NET Framework 4.8."
    },

    # --- API ENDPOINTS & HTTP METHODS ---
    {
        "sentence1": "To generate an API access token, submit a POST request to /v2/auth/tokens.",
        "sentence2": "API token creation is handled via POST requests directed to the /v2/auth/tokens endpoint.",
        "label": 0,
        "domain": "API",
        "explanation": "Consistent endpoint path and HTTP verb for token generation."
    },
    {
        "sentence1": "User profiles can be retrieved by sending a GET request to /api/v1/users/{id}.",
        "sentence2": "Fetching user profile details requires sending a POST request to /api/v1/users/fetch.",
        "label": 1,
        "domain": "API",
        "explanation": "Contradiction in HTTP method and endpoint URI for fetching user profiles."
    },
    {
        "sentence1": "Document deletion requires a DELETE call to /api/v1/documents/{doc_id}.",
        "sentence2": "To delete a document record, dispatch a DELETE request to the /api/v1/documents/{doc_id} URI.",
        "label": 0,
        "domain": "API",
        "explanation": "Matching DELETE endpoint and parameter specification."
    },
    {
        "sentence1": "Updating user records requires a PUT request containing the complete user representation.",
        "sentence2": "User updates must be performed using PATCH requests containing only modified attributes.",
        "label": 1,
        "domain": "API",
        "explanation": "Conflicting API update semantics (full PUT vs partial PATCH)."
    },
    {
        "sentence1": "Bulk record exports are initiated via GET /api/v2/reports/export?format=csv.",
        "sentence2": "Exporting bulk records is triggered by sending a POST request with payload to /api/v2/reports/export.",
        "label": 1,
        "domain": "API",
        "explanation": "Contradictory HTTP method for triggering bulk export operations."
    },
    {
        "sentence1": "The health probe responds with HTTP status 200 at GET /healthz.",
        "sentence2": "Querying GET /healthz yields an HTTP 200 OK status when the node is healthy.",
        "label": 0,
        "domain": "API",
        "explanation": "Consistent health check route and response code."
    },
    {
        "sentence1": "All webhook callbacks are delivered using HTTP POST with JSON body payloads.",
        "sentence2": "Webhook event notifications are dispatched via HTTP PUT to subscriber endpoints.",
        "label": 1,
        "domain": "API",
        "explanation": "Conflicting HTTP verb for webhook event dispatch."
    },

    # --- NETWORKING, PORTS & PROTOCOLS ---
    {
        "sentence1": "The gRPC inter-service RPC listener binds to TCP port 50051.",
        "sentence2": "Inter-service remote procedure calls communicate over port 50051 using gRPC.",
        "label": 0,
        "domain": "Networking",
        "explanation": "Consistent gRPC port 50051 assignment."
    },
    {
        "sentence1": "The administrative control panel is exposed on port 8080 over plain unencrypted HTTP.",
        "sentence2": "The admin portal is strictly accessible on port 8443 requiring TLS 1.3 encryption.",
        "label": 1,
        "domain": "Networking",
        "explanation": "Contradictory port and security protocol (Port 8080 plain HTTP vs Port 8443 TLS 1.3)."
    },
    {
        "sentence1": "Prometheus metrics scraper connects to the /metrics route on port 9090.",
        "sentence2": "Application telemetry and Prometheus metrics are exposed via port 9090 at /metrics.",
        "label": 0,
        "domain": "Networking",
        "explanation": "Consistent metrics port and endpoint documentation."
    },
    {
        "sentence1": "Redis cluster cache communicates across nodes on default port 6379.",
        "sentence2": "Redis cache instances in this environment listen exclusively on non-standard port 16379.",
        "label": 1,
        "domain": "Networking",
        "explanation": "Discrepancy in Redis listening port (6379 vs 16379)."
    },
    {
        "sentence1": "WebSocket real-time connections must establish a secure handshake over wss:// protocol.",
        "sentence2": "Real-time streaming clients must initiate connections using the encrypted wss:// WebSocket scheme.",
        "label": 0,
        "domain": "Networking",
        "explanation": "Consistent requirement for secure wss:// WebSocket transport."
    },
    {
        "sentence1": "DNS resolution queries are directed to internal resolver 10.0.0.2 over UDP port 53.",
        "sentence2": "DNS lookups use DNS-over-HTTPS (DoH) via port 443, blocking standard port 53 UDP traffic.",
        "label": 1,
        "domain": "Networking",
        "explanation": "Contradictory DNS resolution protocol and port architecture."
    },

    # --- SECURITY & AUTHENTICATION ---
    {
        "sentence1": "Client requests must include a valid Bearer token in the HTTP Authorization header.",
        "sentence2": "Authentication is verified via the Authorization header formatted as 'Bearer <token>'.",
        "label": 0,
        "domain": "Security",
        "explanation": "Consistent Bearer token header authentication requirement."
    },
    {
        "sentence1": "All public endpoints authenticate using pre-shared API keys passed in the X-API-Key header.",
        "sentence2": "Authentication is performed exclusively via Mutual TLS (mTLS) client certificates; API key headers are rejected.",
        "label": 1,
        "domain": "Security",
        "explanation": "Contradictory authentication mechanism (API key header vs mTLS client certificates)."
    },
    {
        "sentence1": "User passwords must be hashed using bcrypt with a work factor of at least 12 rounds.",
        "sentence2": "Password storage mandates bcrypt cryptographic hashing with cost parameter set to 12.",
        "label": 0,
        "domain": "Security",
        "explanation": "Consistent bcrypt hashing configuration and work factor."
    },
    {
        "sentence1": "Session tokens expire after 24 hours of continuous inactivity.",
        "sentence2": "Idle session tokens are automatically invalidated after exactly 15 minutes of inactivity.",
        "label": 1,
        "domain": "Security",
        "explanation": "Severe conflict in session expiration duration (24 hours vs 15 minutes)."
    },
    {
        "sentence1": "Data stored in Cloud Storage buckets is encrypted at rest using AES-256 GCM.",
        "sentence2": "At-rest storage encryption utilizes AES-256 Galois/Counter Mode across all cloud volumes.",
        "label": 0,
        "domain": "Security",
        "explanation": "Consistent AES-256 GCM encryption specification."
    },
    {
        "sentence1": "Cross-Origin Resource Sharing (CORS) policy permits wildcard origin '*' on production endpoints.",
        "sentence2": "The CORS configuration strictly disallows wildcard origins and requires explicit domain allowlisting.",
        "label": 1,
        "domain": "Security",
        "explanation": "Contradictory CORS policy (wildcard allow-all vs strict origin whitelist)."
    },
    {
        "sentence1": "Multi-factor authentication (MFA) is mandatory for all user accounts with administrator privileges.",
        "sentence2": "Administrator role access mandates enrollment and verification through multi-factor authentication.",
        "label": 0,
        "domain": "Security",
        "explanation": "Consistent MFA enforcement policy for admin accounts."
    },

    # --- TIMEOUTS, LIMITS & QUOTAS ---
    {
        "sentence1": "The upstream gateway enforces a strict HTTP request timeout of 30 seconds.",
        "sentence2": "Client HTTP requests will be terminated with gateway timeout after 5 seconds of latency.",
        "label": 1,
        "domain": "Configuration",
        "explanation": "Contradictory gateway timeout duration (30 seconds vs 5 seconds)."
    },
    {
        "sentence1": "Database connection pool timeout is configured to 10,000 milliseconds.",
        "sentence2": "Acquiring a connection from the database pool times out after 10 seconds.",
        "label": 0,
        "domain": "Configuration",
        "explanation": "Consistent pool timeout (10,000 ms equals 10 seconds)."
    },
    {
        "sentence1": "Maximum allowable file upload payload is 10 Megabytes.",
        "sentence2": "The file upload service accepts documents and attachments up to 100 Megabytes in size.",
        "label": 1,
        "domain": "Configuration",
        "explanation": "Contradiction in maximum file upload size limit (10 MB vs 100 MB)."
    },
    {
        "sentence1": "Rate limits allow up to 1,000 requests per minute per authenticated API credential.",
        "sentence2": "Authenticated callers are restricted to a rate quota of 1,000 API requests each minute.",
        "label": 0,
        "domain": "Configuration",
        "explanation": "Consistent rate limiting quotas (1,000 req/min)."
    },
    {
        "sentence1": "Unauthenticated client requests are capped at 60 requests per hour per IP address.",
        "sentence2": "Anonymous requests without authentication tokens are granted up to 500 requests per minute.",
        "label": 1,
        "domain": "Configuration",
        "explanation": "Dramatic contradiction in unauthenticated rate limit quotas (60/hour vs 500/min)."
    },
    {
        "sentence1": "The distributed lock expires automatically after 60 seconds if not renewed.",
        "sentence2": "Lock lease duration is 60 seconds with automatic expiration on expiration of the lease.",
        "label": 0,
        "domain": "Configuration",
        "explanation": "Consistent distributed lock TTL duration."
    },

    # --- DATABASE & STORAGE ---
    {
        "sentence1": "The production cluster uses PostgreSQL 16 with Read Committed transaction isolation.",
        "sentence2": "PostgreSQL 16 is deployed across production, configured with Read Committed isolation level.",
        "label": 0,
        "domain": "Database",
        "explanation": "Consistent database engine and transaction isolation specification."
    },
    {
        "sentence1": "The database cluster requires a minimum of 3 primary nodes for consensus voting.",
        "sentence2": "High-availability clustering requires an odd number of voting nodes, with at least 7 active replicas.",
        "label": 1,
        "domain": "Database",
        "explanation": "Contradictory replica count requirements (3 nodes vs 7 nodes)."
    },
    {
        "sentence1": "Database primary keys are 128-bit UUIDv4 identifiers generated on the client side.",
        "sentence2": "Record primary keys use client-generated UUID version 4 string representations.",
        "label": 0,
        "domain": "Database",
        "explanation": "Consistent primary key format (UUIDv4)."
    },
    {
        "sentence1": "Database migrations are applied automatically on application startup using Liquibase.",
        "sentence2": "Automatic database migrations at boot are strictly forbidden; schema updates run via manual CI pipelines.",
        "label": 1,
        "domain": "Database",
        "explanation": "Contradictory migration execution strategy (automatic startup vs manual CI)."
    },
    {
        "sentence1": "Read queries are distributed across read-only replica instances using round-robin routing.",
        "sentence2": "All database operations including SELECT queries must execute directly against the primary master instance.",
        "label": 1,
        "domain": "Database",
        "explanation": "Conflict between replica read distribution and primary-only query execution."
    },
    {
        "sentence1": "Automated snapshot backups execute every 24 hours at 02:00 UTC.",
        "sentence2": "Database volume snapshots are scheduled on a daily basis at 02:00 UTC.",
        "label": 0,
        "domain": "Database",
        "explanation": "Consistent backup schedule documentation."
    },

    # --- CACHING & MEMORY ---
    {
        "sentence1": "User session data is stored in Redis with an eviction policy of volatile-lru.",
        "sentence2": "The Redis cache eviction strategy is set to volatile-lru for user session keys.",
        "label": 0,
        "domain": "Configuration",
        "explanation": "Consistent cache eviction policy."
    },
    {
        "sentence1": "In-memory cache entries have a default time-to-live (TTL) of 3600 seconds.",
        "sentence2": "Cache records are persisted indefinitely with no automatic expiration TTL.",
        "label": 1,
        "domain": "Configuration",
        "explanation": "Contradiction between 1-hour TTL and indefinite cache persistence."
    },
    {
        "sentence1": "Maximum heap size for the search indexing worker is limited to 4 Gigabytes.",
        "sentence2": "The search indexing daemon is allocated up to 16 Gigabytes of maximum heap memory.",
        "label": 1,
        "domain": "Configuration",
        "explanation": "Conflicting JVM heap allocation limits (4 GB vs 16 GB)."
    },
    {
        "sentence1": "Local caching is disabled in multi-tenant environments to prevent cross-tenant leakage.",
        "sentence2": "In multi-tenant configurations, local memory caching is turned off to ensure tenant isolation.",
        "label": 0,
        "domain": "Configuration",
        "explanation": "Consistent cache disablement rule for multi-tenant setups."
    },

    # --- INFRASTRUCTURE & ORCHESTRATION ---
    {
        "sentence1": "Kubernetes pods specify a CPU request of 500m and a limit of 2000m.",
        "sentence2": "Each deployment pod requests 0.5 CPU cores and is capped at 2.0 CPU cores.",
        "label": 0,
        "domain": "Infrastructure",
        "explanation": "Consistent CPU resource requirements (500m = 0.5 CPU, 2000m = 2.0 CPU)."
    },
    {
        "sentence1": "Containers must run as non-root user UID 10001 with read-only root filesystems.",
        "sentence2": "Containerized processes execute with root privileges UID 0 to permit system package installation.",
        "label": 1,
        "domain": "Infrastructure",
        "explanation": "Critical security contradiction (non-root UID 10001 vs root UID 0)."
    },
    {
        "sentence1": "Horizontal Pod Autoscaler scales worker instances between 2 and 20 pods based on CPU utilization.",
        "sentence2": "Autoscaling policies allow scaling between 2 minimum pods and 20 maximum pods.",
        "label": 0,
        "domain": "Infrastructure",
        "explanation": "Consistent autoscaling min/max boundary definitions."
    },
    {
        "sentence1": "Ingress controllers terminate SSL certificates using Let's Encrypt automated cert-manager.",
        "sentence2": "SSL termination is managed by external hardware load balancers with commercial DigiCert wildcard certificates.",
        "label": 1,
        "domain": "Infrastructure",
        "explanation": "Contradictory TLS certificate provisioning and termination layer."
    },
    {
        "sentence1": "Log records are formatted as single-line JSON and streamed to stdout.",
        "sentence2": "Application log output is written in structured JSON format directly to standard output.",
        "label": 0,
        "domain": "Infrastructure",
        "explanation": "Consistent structured JSON logging to stdout."
    },
    {
        "sentence1": "Application logs are written to rotating local files under /var/log/app/app.log.",
        "sentence2": "Local file logging is strictly disabled; all telemetry is transmitted directly over syslog UDP.",
        "label": 1,
        "domain": "Infrastructure",
        "explanation": "Contradictory logging destination (local rotating disk file vs remote syslog UDP)."
    }
]

def expand_dataset(base_data):
    expanded = list(base_data)
    
    # Status codes
    codes = [
        ("POST /api/v1/resource creates records and returns HTTP 201 Created.",
         "Upon successful creation, the /api/v1/resource endpoint responds with status 201 Created.", 0, "Consistent 201 status code."),
        ("POST /api/v1/resource returns HTTP 201 Created on completion.",
         "The resource creation endpoint responds with HTTP 200 OK without a 201 status.", 1, "Contradictory creation status code (201 vs 200)."),
        ("Validation errors return HTTP 422 Unprocessable Entity with error details.",
         "Malformed or invalid request bodies yield an HTTP 422 status code.", 0, "Consistent 422 validation response."),
        ("Invalid parameter values result in HTTP 400 Bad Request.",
         "When validation fails, the service returns HTTP 500 Internal Server Error.", 1, "Contradiction in validation failure status (400 vs 500)."),
        ("Unauthorized requests without authentication headers return HTTP 401 Unauthorized.",
         "Unauthenticated access triggers an HTTP 403 Forbidden error response.", 1, "Conflict between 401 Unauthorized and 403 Forbidden."),
        ("Missing resources return HTTP 404 Not Found.",
         "When an entity ID does not exist, the API responds with HTTP 404 Not Found.", 0, "Consistent 404 response.")
    ]
    for s1, s2, lbl, expl in codes:
        expanded.append({"sentence1": s1, "sentence2": s2, "label": lbl, "domain": "API", "explanation": expl})

    # Timeouts
    timeouts = [
        ("Keep-alive connection duration is set to 65 seconds on the reverse proxy.",
         "The reverse proxy maintains idle keep-alive connections for 65 seconds.", 0, "Consistent keep-alive timeout."),
        ("The proxy keep-alive timeout is configured to 65 seconds.",
         "Keep-alive connections are terminated by the proxy after exactly 10 seconds.", 1, "Contradictory keep-alive duration (65s vs 10s)."),
        ("Client connect timeout to downstream payment gateway is 3000 ms.",
         "Connections to payment providers time out after 3 seconds of unresponsiveness.", 0, "Consistent payment gateway timeout."),
        ("Payment gateway connect timeout is 3000 milliseconds.",
         "Payment provider requests allow up to 60 seconds before aborting the connection.", 1, "Contradictory gateway connect timeout (3s vs 60s)."),
        ("Background worker polling interval is configured to 500 milliseconds.",
         "Background worker tasks poll the task queue every half second.", 0, "Consistent 500ms polling rate."),
        ("Worker poll loop waits 500 milliseconds between queue checks.",
         "Worker queue polling occurs at a 5-minute fixed interval to reduce database load.", 1, "Contradictory polling frequency (500ms vs 5 minutes).")
    ]
    for s1, s2, lbl, expl in timeouts:
        expanded.append({"sentence1": s1, "sentence2": s2, "label": lbl, "domain": "Configuration", "explanation": expl})

    # Buffers
    buffers = [
        ("Maximum WebSocket message frame size is 64 Kilobytes.",
         "WebSocket client frames exceeding 64 KB are rejected with close code 1009.", 0, "Consistent WebSocket frame limit."),
        ("WebSocket incoming frame size limit is 64 Kilobytes.",
         "WebSocket frames up to 16 Megabytes are supported for binary audio streaming.", 1, "Contradictory WebSocket frame size (64 KB vs 16 MB)."),
        ("HTTP request header buffer size is fixed at 8 Kilobytes.",
         "The server accepts HTTP headers up to 8 KB in cumulative length.", 0, "Consistent 8 KB header buffer limit."),
        ("Header buffer size is limited to 8 Kilobytes.",
         "HTTP request headers up to 64 Kilobytes are parsed without truncation.", 1, "Conflicting header buffer size (8 KB vs 64 KB)."),
        ("CSV bulk import accepts file sizes up to 25 Megabytes.",
         "Users may upload CSV import files up to 25 MB in a single transaction.", 0, "Consistent 25 MB CSV upload threshold."),
        ("CSV import payload is capped at 25 Megabytes.",
         "Bulk CSV batch files must not exceed 2 Megabytes per upload.", 1, "Contradictory CSV file size ceiling (25 MB vs 2 MB).")
    ]
    for s1, s2, lbl, expl in buffers:
        expanded.append({"sentence1": s1, "sentence2": s2, "label": lbl, "domain": "Configuration", "explanation": expl})

    # Auth
    auth_pairs = [
        ("JWT access tokens are signed using the asymmetric RS256 algorithm.",
         "Token signature verification relies on RSA with SHA-256 (RS256).", 0, "Consistent JWT signing algorithm."),
        ("JWT tokens are signed using RS256 with public-private keypairs.",
         "JWT authentication verifies tokens using a symmetric HS256 pre-shared secret key.", 1, "Contradictory JWT signature scheme (RS256 vs HS256)."),
        ("Refresh tokens have a maximum validity window of 30 days.",
         "User refresh credentials expire exactly 30 days following issuance.", 0, "Consistent 30-day refresh token lifespan."),
        ("Refresh tokens remain active for 30 days before re-authentication is required.",
         "Refresh tokens expire after 2 hours and must be renewed alongside the access token.", 1, "Severe mismatch in refresh token expiration (30 days vs 2 hours)."),
        ("OAuth2 authorization code flow requires PKCE for all public client apps.",
         "Proof Key for Code Exchange (PKCE) is required for OAuth2 public clients.", 0, "Consistent PKCE requirement."),
        ("All OAuth2 clients must implement PKCE code verifier challenges.",
         "PKCE verification is disabled to maintain backward compatibility with legacy web clients.", 1, "Contradiction in PKCE enforcement.")
    ]
    for s1, s2, lbl, expl in auth_pairs:
        expanded.append({"sentence1": s1, "sentence2": s2, "label": lbl, "domain": "Security", "explanation": expl})

    # Database
    db_pairs = [
        ("Database connection pool maintains a maximum of 50 concurrent connections.",
         "The connection pool size is capped at 50 active database connections.", 0, "Consistent pool connection cap."),
        ("Database max connections limit is set to 50 active sockets.",
         "The database connection pool allows up to 500 concurrent connections per worker node.", 1, "Conflicting database pool capacity (50 vs 500)."),
        ("Indexes on user email columns use case-insensitive B-Tree indexing.",
         "The email address field is indexed using a case-insensitive B-Tree index.", 0, "Consistent email indexing strategy."),
        ("Search queries on username utilize a PostgreSQL GIN index.",
         "User search lookups rely on standard B-tree index scans without full-text GIN indexing.", 1, "Contradictory database index structure (GIN vs B-Tree)."),
        ("Transaction isolation level is configured as Serializable to prevent phantom reads.",
         "Serializable isolation is enforced across all accounting transactions.", 0, "Consistent serializable isolation specification."),
        ("Accounting transactions execute under Serializable isolation level.",
         "Transactions run under Read Uncommitted isolation to maximize write throughput.", 1, "Critical conflict in transaction isolation (Serializable vs Read Uncommitted).")
    ]
    for s1, s2, lbl, expl in db_pairs:
        expanded.append({"sentence1": s1, "sentence2": s2, "label": lbl, "domain": "Database", "explanation": expl})

    # Infrastructure
    infra_pairs = [
        ("Service mesh sidecars communicate using Envoy proxy version 1.28.",
         "Envoy proxy 1.28 is deployed as the service mesh sidecar container.", 0, "Consistent Envoy sidecar version."),
        ("The service mesh sidecar is built on Envoy proxy 1.28.",
         "The mesh uses Linkerd lightweight micro-proxies instead of Envoy.", 1, "Contradictory service mesh architecture (Envoy vs Linkerd)."),
        ("Kafka message retention on the telemetry topic is 7 days.",
         "Events on the telemetry topic are retained in Kafka brokers for one week.", 0, "Consistent 7-day Kafka retention."),
        ("Kafka telemetry topic retention is set to 7 days.",
         "Telemetry messages in Kafka are retained for 24 hours before automatic compaction.", 1, "Conflicting message retention period (7 days vs 24 hours)."),
        ("Kafka partition replication factor is set to 3 across distinct availability zones.",
         "Topic partitions are replicated across 3 separate availability zones.", 0, "Consistent Kafka replication factor."),
        ("Topic replication factor is configured to 3 across availability zones.",
         "Single replica configuration is used for Kafka topics with replication factor 1.", 1, "Contradictory replication factor (3 vs 1)."),
        ("Object storage buckets enable object versioning with lifecycle transitions to Glacier.",
         "S3 buckets are configured with object versioning and transition to Glacier storage.", 0, "Consistent S3 versioning and Glacier policy."),
        ("S3 buckets enable versioning for all stored document artifacts.",
         "Bucket versioning is explicitly disabled to prevent storage cost escalation.", 1, "Contradictory bucket versioning policy (enabled vs disabled)."),
        ("Elasticsearch indexing cluster consists of 5 dedicated master nodes.",
         "The search cluster is coordinated by 5 dedicated master-eligible nodes.", 0, "Consistent Elasticsearch master node topology."),
        ("The search cluster operates with 5 dedicated master nodes.",
         "Elasticsearch runs as a single combined master and data node.", 1, "Contradictory cluster topology (5 dedicated masters vs single combined node).")
    ]
    for s1, s2, lbl, expl in infra_pairs:
        expanded.append({"sentence1": s1, "sentence2": s2, "label": lbl, "domain": "Infrastructure", "explanation": expl})

    # Systematic version pairs
    version_triplets = [
        ("PostgreSQL", "14", "16", "Database"),
        ("MySQL", "5.7", "8.0", "Database"),
        ("Redis", "6.2", "7.2", "Database"),
        ("MongoDB", "5.0", "7.0", "Database"),
        ("Elasticsearch", "7.17", "8.11", "Database"),
        ("RabbitMQ", "3.9", "3.12", "Infrastructure"),
        ("Nginx", "1.20", "1.24", "Networking"),
        ("Apache Kafka", "2.8", "3.6", "Infrastructure"),
        ("Kubernetes", "1.24", "1.30", "Infrastructure"),
        ("Terraform", "1.0", "1.7", "Infrastructure"),
        ("Docker", "20.10", "24.0", "Infrastructure"),
        ("Ubuntu LTS", "20.04", "22.04", "Runtime"),
        ("Debian", "11 Bullseye", "12 Bookworm", "Runtime"),
        ("Alpine Linux", "3.16", "3.19", "Runtime"),
        ("OpenSSL", "1.1.1", "3.0", "Security"),
        ("Rust", "1.70", "1.78", "Runtime"),
        ("TypeScript", "4.9", "5.4", "Runtime"),
        ("C++ standard", "C++17", "C++23", "Runtime"),
        ("Swift", "5.7", "5.10", "Runtime"),
        ("PHP", "8.0", "8.3", "Runtime"),
        ("Scala", "2.13", "3.3", "Runtime"),
        ("Apache Spark", "3.2", "3.5", "Database"),
        ("Grafana", "9.5", "10.4", "Infrastructure"),
        ("Prometheus", "2.35", "2.51", "Infrastructure"),
        ("Consul", "1.12", "1.18", "Infrastructure"),
        ("Vault", "1.11", "1.16", "Security"),
        ("Elasticsearch Client", "7.x", "8.x", "Database"),
        ("Python AsyncIO", "3.8", "3.12", "Runtime"),
        ("Node Engine", "16.x", "20.x", "Runtime"),
        ("Java Spring Boot", "2.7", "3.2", "Runtime")
    ]

    for item, v_old, v_new, dom in version_triplets:
        expanded.append({
            "sentence1": f"The production environment requires {item} version {v_new} or higher.",
            "sentence2": f"Deployment specifications mandate {item} version {v_new} as the base prerequisite.",
            "label": 0,
            "domain": dom,
            "explanation": f"Both documents agree on {item} version {v_new} requirement."
        })
        expanded.append({
            "sentence1": f"The target cluster supports {item} version {v_old} as the standard deployment.",
            "sentence2": f"Support for {item} version {v_old} has been terminated; {item} version {v_new} is strictly required.",
            "label": 1,
            "domain": dom,
            "explanation": f"Direct version contradiction for {item} ({v_old} vs {v_new})."
        })

    # Systematic port pairs
    port_pairs = [
        ("SSH administrative daemon", "22", "2222", "Networking"),
        ("HTTPS web traffic", "443", "8443", "Networking"),
        ("DNS resolution", "53", "853", "Networking"),
        ("NTP time synchronization", "123", "1123", "Networking"),
        ("SNMP monitoring agent", "161", "1161", "Networking"),
        ("LDAP directory service", "389", "636", "Security"),
        ("SMTP mail relay", "25", "587", "Networking"),
        ("IMAP mail client protocol", "143", "993", "Networking"),
        ("Zookeeper client coordination", "2181", "2281", "Infrastructure"),
        ("Consul RPC cluster agent", "8300", "8500", "Infrastructure"),
        ("Vault API listener", "8200", "9200", "Security"),
        ("Jaeger distributed tracing collector", "14268", "14250", "Infrastructure"),
        ("Grafana visualization dashboard", "3000", "3001", "Infrastructure"),
        ("MinIO S3 API gateway", "9000", "9001", "Storage"),
        ("ClickHouse HTTP query interface", "8123", "9000", "Database"),
        ("Cassandra CQL native transport", "9042", "9142", "Database"),
        ("Etcd client communication", "2379", "2380", "Infrastructure"),
        ("Memcached cache daemon", "11211", "11212", "Database"),
        ("PostgreSQL wire protocol", "5432", "5433", "Database"),
        ("MySQL query port", "3306", "3307", "Database")
    ]

    for svc, p1, p2, dom in port_pairs:
        expanded.append({
            "sentence1": f"The {svc} listens on network port {p1}.",
            "sentence2": f"Traffic intended for {svc} is directed to port {p1}.",
            "label": 0,
            "domain": dom,
            "explanation": f"Consistent port {p1} binding for {svc}."
        })
        expanded.append({
            "sentence1": f"The {svc} is configured to bind to port {p1}.",
            "sentence2": f"The {svc} binds exclusively to port {p2}; port {p1} is disabled.",
            "label": 1,
            "domain": dom,
            "explanation": f"Contradictory port configuration for {svc} (port {p1} vs port {p2})."
        })

    # Systematic limits and thresholds
    limit_pairs = [
        ("Maximum database transaction timeout", "5 seconds", "60 seconds", "Database"),
        ("Max concurrent websocket connections per client", "5 connections", "50 connections", "Networking"),
        ("Maximum batch size for bulk insertion", "500 records", "5,000 records", "Database"),
        ("File chunk upload size", "5 Megabytes", "20 Megabytes", "Configuration"),
        ("Maximum length of user password", "64 characters", "128 characters", "Security"),
        ("Maximum retry count on transient network failures", "3 attempts", "10 attempts", "Configuration"),
        ("Circuit breaker failure threshold", "5 consecutive errors", "20 consecutive errors", "Configuration"),
        ("Cache item expiration time", "10 minutes", "24 hours", "Configuration"),
        ("Message queue dead-letter max delivery attempts", "5 deliveries", "15 deliveries", "Infrastructure"),
        ("Maximum query execution time limit", "2000 milliseconds", "30000 milliseconds", "Database"),
        ("Thread pool core size", "8 threads", "64 threads", "Configuration"),
        ("Client idle connection timeout", "30 seconds", "300 seconds", "Networking"),
        ("API gateway request payload limit", "2 MB", "25 MB", "API"),
        ("Audit log retention period", "90 days", "365 days", "Security"),
        ("Backup retention window", "14 days", "60 days", "Database"),
        ("Worker queue max length", "1000 tasks", "50000 tasks", "Infrastructure"),
        ("Max HTTP header size", "8 KB", "32 KB", "Networking"),
        ("Maximum open file descriptors limit", "65535", "1048576", "Infrastructure"),
        ("Database connection pool idle timeout", "60 seconds", "600 seconds", "Database"),
        ("JWT access token lifetime", "15 minutes", "8 hours", "Security")
    ]

    for desc, val1, val2, dom in limit_pairs:
        expanded.append({
            "sentence1": f"{desc} is set to {val1}.",
            "sentence2": f"Configuration rules define {desc.lower()} as {val1}.",
            "label": 0,
            "domain": dom,
            "explanation": f"Both documents declare {desc} as {val1}."
        })
        expanded.append({
            "sentence1": f"{desc} is constrained to {val1}.",
            "sentence2": f"{desc} has been updated to {val2}, superseding the previous {val1} limit.",
            "label": 1,
            "domain": dom,
            "explanation": f"Discrepancy in {desc} ({val1} vs {val2})."
        })

    # Additional diverse architecture pairs
    extra_pairs = [
        ("Storage volumes use ext4 filesystem format for maximum compatibility.",
         "All block storage volumes are formatted using XFS filesystem.", 1, "Storage", "Contradictory filesystem formatting (ext4 vs XFS)."),
        ("Storage volumes are provisioned with XFS filesystem formatting.",
         "Persistent block storage mounts use the XFS filesystem type.", 0, "Storage", "Consistent XFS filesystem documentation."),
        ("Microservices register with Eureka service discovery upon boot.",
         "Consul is utilized as the primary registry for dynamic service discovery.", 1, "Infrastructure", "Conflicting service discovery registries (Eureka vs Consul)."),
        ("Consul is the centralized registry for dynamic service registration.",
         "Dynamic microservice registration and discovery is handled through Consul.", 0, "Infrastructure", "Consistent Consul service discovery specification."),
        ("Application profiling is enabled continuously using Pyroscope agent.",
         "Continuous profiling is collected in production via Pyroscope telemetry.", 0, "Infrastructure", "Consistent Pyroscope profiling integration."),
        ("Continuous profiling is enabled via Pyroscope in all environments.",
         "Runtime profiling is strictly disallowed in production due to overhead.", 1, "Infrastructure", "Contradictory profiling policy (enabled vs disallowed)."),
        ("Metrics are exported using OpenTelemetry Protocol (OTLP) over gRPC.",
         "Telemetry metrics are published using OTLP format across gRPC channels.", 0, "Infrastructure", "Consistent OpenTelemetry export protocol."),
        ("Telemetry metrics are exported via OTLP over gRPC port 4317.",
         "Metrics collection uses legacy StatsD protocol over UDP port 8125.", 1, "Infrastructure", "Contradictory metrics collection protocol (OTLP gRPC vs StatsD UDP)."),
        ("Database read replicas are provisioned in multi-region active-active topology.",
         "Database replicas operate in single-region read-only configuration.", 1, "Database", "Contradictory replica deployment topology."),
        ("Database replicas are deployed across multiple regions in read-only mode.",
         "Read-only replica database nodes are distributed across secondary cloud regions.", 0, "Database", "Consistent multi-region read replica deployment."),
        ("TLS configuration mandates TLS 1.3 protocol and rejects earlier protocol handshakes.",
         "Clients must establish transport security using TLS 1.3 encryption.", 0, "Security", "Consistent TLS 1.3 mandate."),
        ("Transport security enforces TLS 1.3 across all communication channels.",
         "Clients may negotiate connections using TLS 1.0, TLS 1.1, or SSLv3 for backward compatibility.", 1, "Security", "Severe contradiction: modern TLS 1.3 vs obsolete and insecure TLS 1.0/SSLv3."),
        ("Application data directory is located at /var/lib/app/data.",
         "All application persistent state is stored in directory /var/lib/app/data.", 0, "Configuration", "Consistent application state path."),
        ("Persistent files are written to /var/lib/app/data.",
         "Application state must reside entirely on an ephemeral memory disk mounted at /dev/shm.", 1, "Configuration", "Contradictory storage target (/var/lib/app/data vs /dev/shm memory)."),
        ("API pagination uses cursor-based pagination with 'next_cursor' token parameters.",
         "Listing endpoints return cursor tokens for deterministic pagination navigation.", 0, "API", "Consistent cursor-based pagination."),
        ("All collection endpoints implement opaque cursor-based pagination.",
         "Endpoints accept 'page' and 'limit' integer query parameters for offset-based pagination.", 1, "API", "Contradictory pagination strategy (cursor vs offset)."),
        ("Database connection strings must specify sslmode=verify-full.",
         "Clients connecting to PostgreSQL must configure sslmode=verify-full with root CA validation.", 0, "Database", "Consistent sslmode=verify-full requirement."),
        ("Database SSL connections mandate sslmode=verify-full verification.",
         "Database connections disable SSL verification using sslmode=disable for lower latency.", 1, "Database", "Direct conflict between strict verification and disabled SSL."),
        ("The message broker cluster is configured with quorum queues for resilience.",
         "RabbitMQ queues are declared as quorum queues across all worker channels.", 0, "Infrastructure", "Consistent quorum queue declaration."),
        ("Message queues operate using high-availability quorum queues.",
         "Queues are configured as classic mirrored queues with ha-mode policies.", 1, "Infrastructure", "Contradictory queue type (quorum vs legacy mirrored classic queues)."),
        ("Database connection strings must use the postgresql+psycopg2 driver URI format.",
         "PostgreSQL database connections specify the postgresql+psycopg2 adapter prefix.", 0, "Database", "Consistent connection string driver format."),
        ("PostgreSQL driver URI prefix is postgresql+psycopg2.",
         "Connections must use the async asyncpg driver with postgresql+asyncpg prefix.", 1, "Database", "Contradictory driver URI scheme (psycopg2 sync vs asyncpg)."),
        ("API responses are formatted using standard RFC 7807 problem details.",
         "HTTP error bodies strictly adhere to RFC 7807 Problem Details for HTTP APIs.", 0, "API", "Consistent RFC 7807 error format."),
        ("Error structures follow RFC 7807 Problem Details standard specifications.",
         "Error responses return unstructured plain text strings without JSON format.", 1, "API", "Contradiction between RFC 7807 JSON error format and unstructured plain text."),
        ("API clients must send Content-Type: application/json in request headers.",
         "Request payloads must declare Content-Type: application/json header.", 0, "API", "Consistent Content-Type header requirement."),
        ("Payloads require Content-Type: application/json in headers.",
         "Endpoints accept only application/x-www-form-urlencoded form post data.", 1, "API", "Contradictory payload content type (JSON vs form-urlencoded)."),
        ("Database backups are compressed using Zstandard (zstd) algorithm level 3.",
         "Backup archives are compressed via zstd with compression level 3.", 0, "Database", "Consistent zstd compression settings."),
        ("Backups are compressed with Zstandard zstd level 3.",
         "Database backups use uncompressed tar archives to prioritize write speed.", 1, "Database", "Contradictory backup compression specification."),
        ("The server uses ChaCha20-Poly1305 and AES-256-GCM cipher suites.",
         "TLS cipher suites are restricted to ChaCha20-Poly1305 and AES-256-GCM.", 0, "Security", "Consistent cipher suite configuration."),
        ("TLS ciphers are limited to ChaCha20-Poly1305 and AES-256-GCM.",
         "Legacy 3DES and RC4 ciphers are enabled to support outdated client devices.", 1, "Security", "Severe contradiction: strong modern ciphers vs vulnerable 3DES/RC4."),
        ("Session cookies must set SameSite=Strict and Secure attributes.",
         "Authentication cookies enforce SameSite=Strict alongside Secure flags.", 0, "Security", "Consistent cookie security flags."),
        ("Cookies configure SameSite=Strict and Secure flags.",
         "Authentication cookies omit Secure flags and specify SameSite=None for cross-origin sharing.", 1, "Security", "Contradictory cookie security policy."),
        ("Microservice health checks probe /health/ready every 10 seconds.",
         "Readiness probes are polled at a 10-second periodicity at /health/ready.", 0, "Infrastructure", "Consistent readiness probe interval."),
        ("Readiness probes query /health/ready every 10 seconds.",
         "Health readiness is checked every 300 seconds to minimize CPU cycles.", 1, "Infrastructure", "Contradictory health probe frequency (10s vs 300s)."),
        ("Docker base images must be derived from alpine:3.19 or cgr.dev/chainguard/static.",
         "Minimalist container images use alpine:3.19 or Chainguard static base images.", 0, "Infrastructure", "Consistent minimal container base images."),
        ("Container images must use alpine:3.19 or Chainguard minimal images.",
         "All containers are built on full Ubuntu 22.04 desktop base images.", 1, "Infrastructure", "Contradictory base container image sizing and distribution."),
        ("The API gateway terminates TLS and injects X-Forwarded-For headers.",
         "Downstream client IP tracking relies on X-Forwarded-For injected by the TLS gateway.", 0, "Networking", "Consistent X-Forwarded-For header proxying."),
        ("The gateway injects X-Forwarded-For headers for client identification.",
         "X-Forwarded-For headers are stripped by the proxy to preserve user privacy.", 1, "Networking", "Contradictory handling of X-Forwarded-For header."),
        ("Cache invalidation uses Redis Pub/Sub broadcast events across worker nodes.",
         "Worker nodes invalidate local caches upon receiving Redis Pub/Sub events.", 0, "Configuration", "Consistent Pub/Sub cache invalidation."),
        ("Cache invalidation broadcasts across Redis Pub/Sub channels.",
         "Cache invalidation relies solely on passive TTL expiration without messaging.", 1, "Configuration", "Contradictory cache invalidation approach (active pub/sub vs passive TTL)."),
        ("The query optimizer uses cost-based query optimization with statistics auto-analyze.",
         "Query planning executes under cost-based optimization with automated statistics refresh.", 0, "Database", "Consistent query optimizer configuration."),
        ("Database query optimization uses cost-based analysis.",
         "Cost-based optimization is disabled; queries execute strictly with rule-based heuristics.", 1, "Database", "Contradictory query optimization engine (cost-based vs rule-based)."),
        ("Distributed transactions are coordinated using the Saga orchestrator pattern.",
         "Inter-service transactional consistency is achieved through a Saga orchestrator.", 0, "Architecture", "Consistent Saga pattern orchestration."),
        ("Cross-service transactions employ the Saga pattern.",
         "Distributed transactions use two-phase commit (2PC) protocol with global locks.", 1, "Architecture", "Contradictory distributed transaction mechanism (Saga vs 2PC)."),
        ("REST endpoints versioning is managed via URL path prefixes like /v1/ and /v2/.",
         "API versions are declared directly in the URI path hierarchy.", 0, "API", "Consistent URL path versioning."),
        ("API versions are specified in the URL path prefix.",
         "Version negotiation is performed exclusively via the Accept request header.", 1, "API", "Contradictory versioning strategy (URL path vs Accept header)."),
        ("File assets are stored in Amazon S3 or compatible MinIO object storage.",
         "Blob storage uses S3-compatible API buckets provided by AWS or MinIO.", 0, "Storage", "Consistent object storage specifications."),
        ("Blob storage is hosted on S3 or MinIO object buckets.",
         "Files are stored as raw BLOB binary columns directly inside the PostgreSQL database.", 1, "Storage", "Contradictory file storage architecture (Object storage vs DB BLOBs)."),
        ("System metrics are sampled every 5 seconds for high-resolution observability.",
         "Metrics collection operates at a 5-second sampling frequency.", 0, "Infrastructure", "Consistent metrics sampling interval."),
        ("Metrics sampling frequency is set to 5 seconds.",
         "Telemetric data is captured once every 60 minutes to reduce monitoring bandwidth.", 1, "Infrastructure", "Contradictory sampling interval (5 seconds vs 60 minutes)."),
        ("Asynchronous worker queues utilize Redis Streams for event delivery.",
         "Redis Streams provide the message queue backend for worker task dispatches.", 0, "Infrastructure", "Consistent Redis Streams queue engine."),
        ("Worker tasks are dispatched using Redis Streams.",
         "Worker queue tasks are managed using an external AWS SQS FIFO queue.", 1, "Infrastructure", "Contradictory worker queue engine (Redis Streams vs AWS SQS)."),
        ("API access tokens must be refreshed every 3600 seconds.",
         "Tokens require refreshing after one hour of operation.", 0, "Security", "Consistent 1-hour token renewal."),
        ("Access tokens expire after 3600 seconds and must be renewed.",
         "Tokens are valid permanently for 10 years without requiring renewal.", 1, "Security", "Contradictory token lifespan (3600s vs 10 years)."),
        ("Database connections must configure a connect_timeout of 5 seconds.",
         "Connection attempts to the database timeout after 5000 milliseconds.", 0, "Database", "Consistent database connection timeout."),
        ("Database connection timeout is 5 seconds.",
         "The database client attempts connections with infinite timeout until successful.", 1, "Database", "Contradictory connection timeout (5s vs infinite)."),
        ("Cross-origin HTTP requests require an Origin header matching configured allowed domains.",
         "Browser CORS enforcement checks incoming Origin headers against the allowed domains list.", 0, "Security", "Consistent CORS Origin header check."),
        ("CORS requests must match the allowed domains list.",
         "Cross-origin requests are accepted unconditionally from any caller domain.", 1, "Security", "Contradictory CORS origin policy."),
        ("The message broker cluster runs in high availability mode across 3 availability zones.",
         "Three distinct cloud availability zones host the redundant message broker nodes.", 0, "Infrastructure", "Consistent 3-AZ high availability."),
        ("Message brokers are deployed across 3 availability zones.",
         "The message broker runs on a single node without high-availability clustering.", 1, "Infrastructure", "Contradictory broker availability architecture."),
        ("Kubernetes readiness probes utilize an HTTP GET endpoint at /livez.",
         "Readiness checks evaluate service availability via HTTP GET to /livez.", 0, "Infrastructure", "Consistent readiness probe route."),
        ("Readiness probes hit the /livez HTTP route.",
         "Readiness is verified via a custom TCP socket connection on port 9999 without HTTP.", 1, "Infrastructure", "Contradictory readiness probe mechanism."),
        ("Kafka consumer groups implement cooperative sticky rebalancing protocol.",
         "The Kafka client configuration specifies CooperativeStickyAssignor for partition assignment.", 0, "Infrastructure", "Consistent Kafka partition rebalancing strategy."),
        ("Kafka partition assignor is configured as CooperativeStickyAssignor.",
         "Consumer rebalancing uses eager RangeAssignor causing full consumer group pauses.", 1, "Infrastructure", "Contradictory partition assignment strategy."),
        ("API rate limit excess returns HTTP 429 Too Many Requests with Retry-After header.",
         "Exceeded quota requests receive HTTP 429 and include Retry-After seconds in header.", 0, "API", "Consistent 429 rate limit response."),
        ("Rate limit violations yield status 429 with Retry-After headers.",
         "Over-quota requests are throttled silently with HTTP 200 OK and empty payloads.", 1, "API", "Contradictory rate limit error response (429 vs silent 200)."),
        ("SQL queries must use parameterized placeholders to prevent SQL injection.",
         "All database access layers enforce prepared statements with parameter binding.", 0, "Security", "Consistent parameterized query requirement."),
        ("Database access strictly requires parameterized statements.",
         "Dynamic SQL queries concatenate user strings directly into SQL statement buffers.", 1, "Security", "Severe vulnerability and contradiction: parameterized vs string concatenation."),
        ("Docker multi-stage builds are used to produce minimal production images.",
         "Production container artifacts are assembled using multi-stage Docker build files.", 0, "Infrastructure", "Consistent Docker multi-stage build design."),
        ("Container builds use multi-stage compilation steps.",
         "Images are built in a single stage containing full compiler toolchains and headers.", 1, "Infrastructure", "Contradictory container build architecture."),
        ("Distributed locks are stored in Redis using Redlock consensus algorithm.",
         "Distributed mutual exclusion uses Redlock implementation across Redis nodes.", 0, "Infrastructure", "Consistent Redlock algorithm specification."),
        ("Distributed locks use Redlock consensus across Redis instances.",
         "Distributed concurrency uses OS-level filesystem flock on an NFS shared volume.", 1, "Infrastructure", "Contradictory distributed lock implementation (Redlock vs NFS flock).")


    ]

    for s1, s2, lbl, dom, expl in extra_pairs:
        expanded.append({"sentence1": s1, "sentence2": s2, "label": lbl, "domain": dom, "explanation": expl})

    for idx, item in enumerate(expanded):
        item["id"] = idx + 1

    return expanded

if __name__ == "__main__":
    dataset = expand_dataset(DATASET)
    output_dir = os.path.join(os.path.dirname(__file__), "..", "data")
    os.makedirs(output_dir, exist_ok=True)
    out_path = os.path.join(output_dir, "sample_training_data.json")
    
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(dataset, f, indent=2, ensure_ascii=False)
        
    c0 = sum(1 for d in dataset if d["label"] == 0)
    c1 = sum(1 for d in dataset if d["label"] == 1)
    print(f"Generated {len(dataset)} sentence pairs.")
    print(f"Consistent (0): {c0}, Contradictory (1): {c1}")
    print(f"Saved to: {os.path.abspath(out_path)}")
