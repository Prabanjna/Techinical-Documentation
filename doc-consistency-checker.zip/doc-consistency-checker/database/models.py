"""
SQLAlchemy Data Models for Technical Documentation Consistency Checker.
Stores Users, Analyses, Documents, and Inconsistency Pairs.
"""

from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, Boolean, Text, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from database.db import Base

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(64), unique=True, nullable=False, index=True)
    password_hash = Column(String(256), nullable=False)
    role = Column(String(32), default="engineer")
    created_at = Column(DateTime, default=datetime.utcnow)

    analyses = relationship("Analysis", back_populates="user", cascade="all, delete-orphan")


class Analysis(Base):
    __tablename__ = "analyses"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    title = Column(String(256), nullable=False)
    
    doc_a_name = Column(String(256), nullable=False)
    doc_b_name = Column(String(256), nullable=False)
    doc_a_path = Column(String(512), nullable=True)
    doc_b_path = Column(String(512), nullable=True)
    doc_a_format = Column(String(16), default="pdf")
    doc_b_format = Column(String(16), default="pdf")

    overall_score = Column(Float, default=100.0)
    total_pairs = Column(Integer, default=0)
    contradiction_count = Column(Integer, default=0)
    consistent_count = Column(Integer, default=0)
    critical_count = Column(Integer, default=0)
    moderate_count = Column(Integer, default=0)
    minor_count = Column(Integer, default=0)
    
    status = Column(String(32), default="completed")  # pending, processing, completed, failed
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="analyses")
    inconsistencies = relationship("Inconsistency", back_populates="analysis", cascade="all, delete-orphan")


class Inconsistency(Base):
    __tablename__ = "inconsistencies"

    id = Column(Integer, primary_key=True, index=True)
    analysis_id = Column(Integer, ForeignKey("analyses.id"), nullable=False)

    section_a_id = Column(String(64), nullable=True)
    section_a_title = Column(String(256), nullable=False)
    section_a_text = Column(Text, nullable=False)
    page_a = Column(Integer, default=1)
    bbox_a = Column(Text, nullable=True)  # JSON string of [x0, y0, x1, y1]
    para_idx_a = Column(Integer, nullable=True)

    section_b_id = Column(String(64), nullable=True)
    section_b_title = Column(String(256), nullable=False)
    section_b_text = Column(Text, nullable=False)
    page_b = Column(Integer, default=1)
    bbox_b = Column(Text, nullable=True)  # JSON string of [x0, y0, x1, y1]
    para_idx_b = Column(Integer, nullable=True)

    similarity_score = Column(Float, default=0.0)
    confidence = Column(Float, default=0.0)
    is_contradictory = Column(Boolean, default=False)
    prediction_label = Column(String(32), default="Consistent")
    severity = Column(String(32), default="None")  # Critical, Moderate, Minor, None
    
    explanation = Column(Text, nullable=True)
    influential_words_a = Column(Text, nullable=True)  # JSON list
    influential_words_b = Column(Text, nullable=True)  # JSON list
    highlighted_text_a = Column(Text, nullable=True)
    highlighted_text_b = Column(Text, nullable=True)

    analysis = relationship("Analysis", back_populates="inconsistencies")
