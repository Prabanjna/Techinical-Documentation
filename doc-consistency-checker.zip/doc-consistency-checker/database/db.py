"""
Database setup for Technical Documentation Consistency Checker.
Uses SQLAlchemy with SQLite default (can swap to PostgreSQL via DATABASE_URL).
"""

import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

DB_PATH = os.path.join(os.path.dirname(__file__), "doc_checker.db")
DATABASE_URL = os.getenv("DATABASE_URL", f"sqlite:///{DB_PATH}")

# SQLite multithreading compatibility
connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}

engine = create_engine(DATABASE_URL, echo=False, connect_args=connect_args)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()

def init_db():
    """Initializes all database tables."""
    import database.models  # Ensure models are imported before creating tables
    Base.metadata.create_all(bind=engine)

def get_db():
    """Yields a database session context."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
